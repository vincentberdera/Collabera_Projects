import { LightningElement, api } from 'lwc';
import ID_FIELD from "@salesforce/schema/Bill__c.Id";
import LOCATION from '@salesforce/schema/Bill__c.Location__c';
import CATEGORY from '@salesforce/schema/Bill__c.Category__c';
import AMOUNT from '@salesforce/schema/Bill__c.Amount__c';
import PAY_BEFORE from '@salesforce/schema/Bill__c.Pay_Before__c';
import USER from '@salesforce/schema/Bill__c.For_User__c';

import { updateRecord } from 'lightning/uiRecordApi';
import {ShowToastEvent} from 'lightning/platformShowToastEvent';
import { NavigationMixin } from 'lightning/navigation';

export default class BillsModal extends NavigationMixin(LightningElement) {

    fields = [LOCATION,CATEGORY,AMOUNT,PAY_BEFORE,USER];
    objectName = 'Bill__c';

    addRecord;

    @api passedId;

    showModal=false;

    @api addRecord=false;

    location = LOCATION;
    category = CATEGORY;
    amount = AMOUNT;
    payBefore = PAY_BEFORE;
    userId = USER;

    @api idRecord;

    @api show(){
        this.showModal = true;
    }

    handleDialogClose(){
        this.showModal = false;
    }

    handleCancelEditForm()
    {
        this.showModal = false;
    }

    handleCancel(){
        this.showModal = false;
    }

    handleSaveEditForm()
    {
        const recordField = {};
        
        recordField[ID_FIELD.fieldApiName] = this.passedId;
        recordField[LOCATION.fieldApiName] = this.template.querySelector("[data-field='Location__c']").value;
        recordField[CATEGORY.fieldApiName] = this.template.querySelector("[data-field='Category__c']").value;
        recordField[AMOUNT.fieldApiName] = this.template.querySelector("[data-field='Amount__c']").value;
        recordField[PAY_BEFORE.fieldApiName] = this.template.querySelector("[data-field='Pay_Before__c']").value;
        recordField[USER.fieldApiName] = this.template.querySelector("[data-field='For_User__c']").value;

        const recordInput ={
            fields:recordField
        }
        updateRecord(recordInput).then(() => {
            this.dispatchEvent(
                new ShowToastEvent({
                    title: 'Success',
                    message: 'Bill updated',
                    variant: 'success'
                })
            );
            window.location.reload();
        })
        .catch(error => {
            this.dispatchEvent(
                new ShowToastEvent({
                    title: 'Error updating record',
                    message: error.body.message,
                    variant: 'error'
                })
            );
        });
        this.showModal = false;
        this.addRecord = true;
        this.reloadPage();
    }

    reloadPage() {
        // Navigate to the Account home page
        this[NavigationMixin.Navigate]({
            "type": "standard__webPage",
            "attributes": {
                "url": "https://paypalclonecompany-dev-ed.lightning.force.com/lightning/n/Support_Bills"
            }
        });
    }

}