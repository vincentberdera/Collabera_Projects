import { LightningElement, api } from 'lwc';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import { NavigationMixin } from 'lightning/navigation';
import getBillsRecords from '@salesforce/apex/PaypalRecords.fetchBillsRecord';
import getWalletRecords from '@salesforce/apex/PaypalRecords.fetchWalletRecord';
import updateWalletRecords from '@salesforce/apex/PaypalRecords.updateWalletRecord';
import {refreshApex} from '@salesforce/apex';

const cols = [
    {
        label:'Name',
        fieldName: 'Name',
        type: 'text'
    },
    {
        label:'Category',
        fieldName: 'Category',
        type: 'text'
    },
    {
        label:'Amount',
        fieldName: 'Amount',
        type: 'currency'
    },
    {
        label:'Offer Applied',
        fieldName: 'OfferApplied',
        type: 'percent'
    },
    {
        label:'Pay Before',
        fieldName: 'PayBefore',
        type: 'date'
    },
    {
        label:'Paid',
        fieldName: 'Paid',
        type: 'text'
    },
    {
        label:'Successful',
        fieldName: 'Successful',
        type: 'text'
    },
    {
        type:"button",
        fixedWidth: 150,
        typeAttributes: {
            label: 'Pay',
            value: 'Id',
            name: 'edit',
            variant: 'success'
        }
    }
]

export default class BillsPage extends NavigationMixin(LightningElement) {

    Cash;
    ToPay;
    isPaid;

    @api idWallet;
    @api idBill;

    columns = cols;
    result;
    error;

    
    result2;
    error2;

    @api errorMessage;

    connectedCallback(){
        this.handleBillsData();
        this.handleWalletRecords();
    }

    handleBillsData(){
        getBillsRecords({}).then(res=>{
            let finalChange=[];
            res.forEach(row=>{
                let objectStruct = {};
                objectStruct.Id = row.Id;
                objectStruct.Name = row.Name;
                objectStruct.Location = row.Location__c;
                objectStruct.Category = row.Category__c;
                objectStruct.Amount = row.Amount__c;
                objectStruct.OfferApplied = row.Offer_Applied__c/100;
                
                objectStruct.PayBefore = row.Pay_Before__c;
                objectStruct.Paid = row.Paid__c;
                objectStruct.Successful = row.Successful__c;
                objectStruct.ForUser = row.For_User__r.Name;
                finalChange.push(objectStruct);
            })
            this.result = finalChange;
        }).catch(err => {
            this.error = err;
        })
    }
    
    handleWalletRecords(){
        getWalletRecords({}).then(res => {
            let finalChange=[];
            res.forEach(row => {
                console.log("wow");
                let objectStruct = {};      
                objectStruct.Id2 = row.Id;    
                this.idWallet = row.Id;      
                objectStruct.Balance = row.Balance__c;
                this.Cash = row.Balance__c;
                console.log(row.Balance__c);
                objectStruct.Name2 = row.Added_From__r.Name;
                finalChange.push(objectStruct);
            })
            this.result2 = finalChange;
        })
        .catch(err => {
            this.error2 = err;
        })
    }

    navigateToPayBills(event){        
        this.idBill = event.detail.row.Id;
        this.isPaid = event.detail.row.Paid ;
        console.log('checking this: ' + event.detail.row.Paid)
        if(event.detail.row.OfferApplied>0){
            this.ToPay = event.detail.row.Amount - (event.detail.row.Amount * (event.detail.row.OfferApplied / 100));
            console.log(this.ToPay);
        }
        else{
            this.ToPay = event.detail.row.Amount;
        }

        if(this.isPaid == false){
            if(this.Cash < this.ToPay)
            {
                console.log(this.Cash - this.ToPay);
                this.NotEnoughCash();
            }
            else{
                console.log(this.Cash - this.ToPay);
                this.handlePayBills();
            }
        }
        else{
            const evt = new ShowToastEvent({
                title: 'Hello!',
                message: 'You already paid for this bill.',
                variant: 'info',
                mode: 'dismissable'
            });
            this.dispatchEvent(evt);
        }
        
    }
    
    NotEnoughCash(){
        const evt = new ShowToastEvent({
            title: 'Warning!',
            message: 'Insufficient balance',
            variant: 'error',
            mode: 'dismissable'
        });
        this.dispatchEvent(evt);

        this[NavigationMixin.Navigate]({
            type: 'standard__webPage',
            attributes: {
                url: 'https://paypalclonecompany-dev-ed.lightning.force.com/lightning/n/Wallet'
            }
        });
    }

    handlePayBills(){
        const evt = new ShowToastEvent({
            title: 'Congratulations!',
            message: 'You sucessfully paid your bill',
            variant: 'success',
            mode: 'dismissable'
        });
        this.dispatchEvent(evt);
        updateWalletRecords({
            walletId:this.idWallet,
            billId:this.idBill
        }).then(()=>{
            return refreshApex(this.handleBillsData())
        }).catch((error)=>{
            this.errorMessage = error;
            console.log('unable to update the record'+JSON.stringify(this.errorMessage));
        })
    }
}