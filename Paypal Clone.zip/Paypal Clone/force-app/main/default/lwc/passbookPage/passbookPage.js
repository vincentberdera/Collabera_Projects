import { LightningElement } from 'lwc';
import pdflib from '@salesforce/resourceUrl/pdflib';
import { loadScript } from "lightning/platformResourceLoader";
import {refreshApex} from '@salesforce/apex';
import { updateRecord } from 'lightning/uiRecordApi';
import {ShowToastEvent} from 'lightning/platformShowToastEvent';
import getPassbookRecords from '@salesforce/apex/PaypalRecords.fetchPassobookRecord';
import ID_FIELD from "@salesforce/schema/Passbook__c.Id";
import FLAG_FIELD from "@salesforce/schema/Passbook__c.IsFlagged__c";


const cols = [
    {
        label:'Vendor Name',
        fieldName:'Name',
        type:'text'
    },
    {
        label:'User',
        fieldName:'UserName',
        type:'text'
    },
    {
        label:'Expense Description',
        fieldName:'ExpenseDescription',
        type:'text'
    },
    {
        label:'Amount',
        fieldName:'Amount',
        type:'currency'
    },
    {
        label:'Datetime',
        fieldName:'Datetime',
        type:'datetime'
    },
    {
        label:'Comment',
        fieldName:'Comment',
        type:'text'
    },
    {
        label:'Flagged?',
        fieldName:'Flag',
        type:'checkbox'
    },
    {
        label: 'Action',
        type:"button",
        fieldName: 'Send',
        fixedWidth: 150,
        typeAttributes: {
            label: 'Send PDF',
            value: 'Id',
            name: 'edit',
            variant: 'success'
        }
    }
];

export default class PassbookPage extends LightningElement {

    columns = cols;
    result;
    error;

    comment;

    connectedCallback(){
        this.handlePassbookData();
    }

    handlePassbookData(){
        getPassbookRecords({}).then(res=>{
            let finalChange=[];
            res.forEach(row=>{
                let objectStruct = {};
                objectStruct.Id = row.Id;
                objectStruct.Name = row.Name;
                objectStruct.UserName = row.User__r.Name;
                objectStruct.ExpenseDescription = row.Expense_Description__c;
                objectStruct.Amount = row.Amount__c;
                objectStruct.Datetime = row.Datetime__c;
                objectStruct.Comment = row.Comment__c;
                objectStruct.Flag = row.IsFlagged__c;
                finalChange.push(objectStruct);
            })
            this.result = finalChange;
        }).catch(err => {
            this.error = err;
        })
    }

    renderedCallback(){
        loadScript(this, pdflib).then(()=>{});
    }

    async navigateToSendPDF(event){
        console.log('wow');
        const pdfDoc = await PDFLib.PDFDocument.create();
        const timesRomanFont = await pdfDoc.embedFont(PDFLib.StandardFonts.TimesRoman);
        const page = pdfDoc.addPage();
        const { width, height } = page.getSize();
        const fontSize = 20;

        this.comment = event.detail.row.Comment;

        if(this.comment == null || this.comment ==''){
            this.comment='';
        }
        const selectedRows = event.detail.selectedRows;
        for (let i = 0; i < selectedRows.length; i++) {
            alert('You selected: ' + selectedRows[i].opportunityName);
        }

        page.drawText('PASSBOOK RECORDS\n\n' + 'Passbook ID: ' + event.detail.row.Id + '\n' +  'Vendor Name: ' + event.detail.row.Name + '\n' +  'User: ' + event.detail.row.UserName + '\n' +  'Expense Description: ' + event.detail.row.ExpenseDescription + '\n' +  'Amount: ' + event.detail.row.Amount + '\n' +  'Datetime: ' + event.detail.row.Datetime + '\n' +  'Comment: ' + this.comment, {
          x: 50,
          y: height - 4 * fontSize,
          size: fontSize,
          font: timesRomanFont,
          color: PDFLib.rgb(0, 0, 0),
        });
      
        const pdfBytes = await pdfDoc.save();
        this.saveByteArray("Passbook PDF", pdfBytes);
    }

    saveByteArray(pdfName, byte){
        var blob = new Blob([byte], {type:"application/pdf"});
        var link = document.createElement("a");
        link.href = window.URL.createObjectURL(blob);
        var fileName = pdfName;
        link.download = fileName;
        link.click();
    }

    handleFlagSelectedRows()
    {
        let selectedRows = this.template.querySelector('lightning-datatable').getSelectedRows();
        if(selectedRows.length >0)
        {
            console.log('wow1');
            for(let i =0; i<selectedRows.length;i++)
            {
                const recordField = {};
                recordField[ID_FIELD.fieldApiName] = selectedRows[i].Id;
                recordField[FLAG_FIELD.fieldApiName] = true;

                const recordInput ={
                    fields:recordField
                }

                console.log('wow2');
                updateRecord(recordInput).then(() => {
                    
                console.log('wow3');
                    this.dispatchEvent(
                        new ShowToastEvent({
                            title: 'Success',
                            message: 'Record has been Flagged',
                            variant: 'success'
                        })
                    );
                    refreshApex(this.data);
                })
                .catch(error => {
                    this.dispatchEvent(
                        new ShowToastEvent({
                            title: 'Error flagging records',
                            message: error.body.message,
                            variant: 'error'
                        })
                    );
                });
            }
            console.log(selectedRows);
        }
        else
        {
            console.log('No Items');
        }
    }

}