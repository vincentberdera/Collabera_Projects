import { LightningElement, api } from 'lwc';
import AMOUNT from '@salesforce/schema/Wallet__c.Balance__c';
import getWallet from '@salesforce/apex/PaypalRecords.transferToPal'
import {ShowToastEvent} from 'lightning/platformShowToastEvent';

export default class PalModal extends LightningElement {
    showModal=false;
    objectName = 'Wallet__c';
    balance = AMOUNT;


    @api idPassed;
    @api idSender;
    @api nameReceiver;

    @api show(){
        this.showModal = true;
    }

    handleDialogClose(){
        this.showModal = false;
    }

    handleCancelEditForm()
    {
        this.showModal = false;
    }

    handleSaveEditForm(){
        console.log(this.idPassed);
        console.log(this.idSender);
        console.log(this.template.querySelector("[data-field='Balance__c']").value);
        const evt = new ShowToastEvent({
            title: 'Success!',
            message: 'Transaction Success!',
            variant: 'success',
            mode: 'dismissable'
        });
        this.dispatchEvent(evt);
        getWallet({
            walletId1:this.idSender,
            walletId2:this.idPassed,
            AmountToTransfer:this.template.querySelector("[data-field='Balance__c']").value
        }).then(()=>{
            
        }).catch((error)=>{
            this.errorMessage = error;
            console.log('unable to update the record'+JSON.stringify(this.errorMessage));
        })
        this.showModal = false;
    }

}