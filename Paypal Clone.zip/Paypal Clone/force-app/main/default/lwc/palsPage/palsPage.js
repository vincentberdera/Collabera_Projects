import { LightningElement } from 'lwc';
import { NavigationMixin } from 'lightning/navigation';
import getPals from '@salesforce/apex/PaypalRecords.fetchPals';

const cols = [
    {
        label:'Name',
        type: "button",
        typeAttributes: {  
            label:{
                fieldName:'Name'
            },variant: 'base',
        name: 'Name',  
        title: 'Edit',  
        disabled: false,  
        value: 'Id',  
        iconPosition: 'left'
    }}
];

export default class PalsPage extends NavigationMixin(LightningElement) {
    
    searchKey;

    sender;
    senderName;

    columns = cols;
    result;
    error;

    connectedCallback(){
        this.handlePalData();
    }

    handleAddPal(){
        this[NavigationMixin.Navigate]({
            type: 'standard__objectPage',
            attributes: {
                objectApiName: 'Pals__c',
                actionName: 'new'
            }
        });
    }

    handleKeys(e){
        this.searchKey = e.target.value;
        console.log(this.searchKey);
        this.handlePalData();
    }

    handlePalData(){
        getPals({'Search':this.searchKey}).then(res=>{
            if(res){
                let finalChange=[];
                res.forEach(row=>{
                    let objectStruct = {};
                    objectStruct.Id = row.User__c;
                    objectStruct.Name = row.User__r.Name;
                    this.senderName = row.User__r.Name;
                    this.sender = row.CreatedById;
                    finalChange.push(objectStruct);
                })
                this.result = finalChange;
            }
        }).catch(err=>{
            this.error = err;
        })
    }

    handleClick(event) {
        const rowNode = event.toElement.closest('tr');
    
        // Row index (-1 to account for header row)
        console.log(rowNode.rowIndex - 1);
    
        // Row Id
        console.log(rowNode.dataset.rowKeyValue);
    
        // Use either of these to get the row data from the table data
    }

    handleSendMoney(event){
        const modal = this.template.querySelector("c-pal-modal");
        modal.idPassed = event.detail.row.Id;
        modal.idSender = this.sender;
        modal.nameReceiver = this.senderName;
        modal.show();
    }

}