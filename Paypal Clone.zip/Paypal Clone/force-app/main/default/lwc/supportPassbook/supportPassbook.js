import { LightningElement, api } from 'lwc';
import { loadScript } from "lightning/platformResourceLoader";
import {refreshApex} from '@salesforce/apex';
import { updateRecord } from 'lightning/uiRecordApi';
import {ShowToastEvent} from 'lightning/platformShowToastEvent';
import getPassbookRecords from '@salesforce/apex/PaypalRecords.fetchPassobookRecordforAdmin';
import ID_FIELD from "@salesforce/schema/Passbook__c.Id";
import FLAG_FIELD from "@salesforce/schema/Passbook__c.IsFlagged__c";
import getPassbook from '@salesforce/apex/PaypalRecords.fetchPassobookRecord2';
import DebitCreditUsers from '@salesforce/apex/PaypalRecords.DebitCredtUsers';


const cols = [
    {
        label:'Vendor Name',
        fieldName:'Name',
        type:'text'
    },
    {
        label:'User',
        fieldName:'UserName',
        type:'text'
    },
    {
        label:'Expense Description',
        fieldName:'ExpenseDescription',
        type:'text'
    },
    {
        label:'Amount',
        fieldName:'Amount',
        type:'currency'
    },
    {
        label:'Datetime',
        fieldName:'Datetime',
        type:'datetime'
    },
    {
        label:'Comment',
        fieldName:'Comment',
        type:'text'
    },
    {
        label:'Flagged?',
        fieldName:'Flag',
        type:'checkbox'
    },
    {
        label:'Cancelled?',
        fieldName:'cancelled',
        type:'checkbox'
    },
    {
        label: 'Action',
        type:"button",
        fixedWidth: 250,
        typeAttributes: {
            label: 'Cancel Transaction',
            value: 'Id',
            name: 'edit',
            variant: 'success'
        }
    }
];

export default class SupportPassbook extends LightningElement {

    columns = cols;
    result;
    error;

    comment;

    @api recordId;
    @api passbookId;
    @api venderName;
    @api userId;
    @api amount;
    @api cancelled;

    connectedCallback(){
        this.handlePassbookData();
    }

    handlePassbookData(){
        getPassbookRecords({}).then(res=>{
            let finalChange=[];
            res.forEach(row=>{
                let objectStruct = {};
                objectStruct.Id = row.Id;
                objectStruct.Name = row.Name;
                objectStruct.UserName = row.User__r.Name;
                objectStruct.ExpenseDescription = row.Expense_Description__c;
                objectStruct.Amount = row.Amount__c;
                objectStruct.Datetime = row.Datetime__c;
                objectStruct.Comment = row.Comment__c;
                objectStruct.Flag = row.IsFlagged__c;
                objectStruct.cancelled = row.isCancelled__c;
                finalChange.push(objectStruct);
            })
            this.result = finalChange;
        }).catch(err => {
            this.error = err;
        })
    }

    handleFlagSelectedRows()
    {
        let selectedRows = this.template.querySelector('lightning-datatable').getSelectedRows();
        if(selectedRows.length >0)
        {
            console.log('wow1');
            for(let i =0; i<selectedRows.length;i++)
            {
                const recordField = {};
                recordField[ID_FIELD.fieldApiName] = selectedRows[i].Id;
                recordField[FLAG_FIELD.fieldApiName] = true;

                const recordInput ={
                    fields:recordField
                }

                console.log('wow2');
                updateRecord(recordInput).then(() => {
                    
                console.log('wow3');
                    this.dispatchEvent(
                        new ShowToastEvent({
                            title: 'Success',
                            message: 'Record has been Flagged',
                            variant: 'success'
                        })
                    );
                    refreshApex(this.data);
                })
                .catch(error => {
                    const evt = new ShowToastEvent({
                        title: 'No Items',
                        message: error.body.message,
                        variant: 'error',
                        mode: 'dismissable'
                    });
                    this.dispatchEvent(evt);
                });
            }
            this.template.querySelector('lightning-datatable').selectedRows = [];
            console.log(selectedRows);
        }
        else
        {
            console.log('No Items');
            const evt = new ShowToastEvent({
                title: 'No Items',
                message: error.body.message,
                variant: 'error',
                mode: 'dismissable'
            });
            this.dispatchEvent(evt);
        }
    }

    handleCancelRecords(event){
        this.recordId = event.detail.row.Id;
        getPassbook({'recordId':this.recordId}).then(res=>{
            if(res){
                res.forEach(row => {
                    this.passbookId = row.Id;
                    this.venderName = row.Name;
                    this.userId = row.User__c;
                    this.amount = row.Amount__c;
                    this.cancelled = row.isCancelled__c;
                    console.log(this.passbookId);
                    console.log(this.venderName);
                    console.log(this.userId);
                    console.log(this.amount);
                });
                if(this.cancelled != true){
                    const evt = new ShowToastEvent({
                        title: 'Congratulations!',
                        message: 'You sucessfully cancelled the transaction',
                        variant: 'success',
                        mode: 'dismissable'
                    });
                    this.dispatchEvent(evt);
                    
                    DebitCreditUsers({
                        passbookId:this.passbookId,
                        walletId1:this.userId,
                        walletId2:this.venderName,
                        AmountToTransfer:this.amount
                    }).then(()=>{
                        return refreshApex(this.handlePassbookData())
                    }).catch((error)=>{
                        this.errorMessage = error;
                        console.log('unable to update the record'+JSON.stringify(this.errorMessage));
                    })
                }
                else{
                    const evt = new ShowToastEvent({
                        title: 'Unseccessfull!',
                        message: 'You already cancelled this transaction',
                        variant: 'error',
                        mode: 'dismissable'
                    });
                    this.dispatchEvent(evt);
                }
                
            }
        })
    }

}