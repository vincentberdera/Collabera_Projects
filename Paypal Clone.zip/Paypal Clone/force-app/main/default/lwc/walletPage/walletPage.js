import { LightningElement } from 'lwc';
import USER from '@salesforce/schema/Wallet__c.Added_From__c';
import DATE_TIME from '@salesforce/schema/Wallet__c.Datetime__c';
import checkuser from '@salesforce/apex/PaypalRecords.checkUser';
import getWalletRecords from '@salesforce/apex/PaypalRecords.fetchWalletRecord';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import { NavigationMixin } from 'lightning/navigation';

export default class WalletPage extends NavigationMixin(LightningElement) {
    
    fields = [USER,DATE_TIME];
    isShow;
    Balance;
    owns;

    idRecord;
    
    connectedCallback(){
        this.checkuser();
    }

    checkuser(){
        checkuser({})
            .then(result => {
                console.log(result);
                this.isShow = result;
                if(this.isShow==true){
                    console.log("wow");
                    this.handleWalletRecords();
                }
            })
            .catch(error => {
                console.log('error: ', error);
            });
    }
    handleWalletRecords(){
        console.log("result");
        getWalletRecords({})
            .then(result => {
                result.forEach(row => {
                    this.idRecord = row.Id;
                    this.Balance = row.Balance__c;
                    console.log(row.Balance__c);
                    this.owns = row.Added_From__r.Name;
                    console.log(row.Added_From__r.Name);

                })
                console.log(result);
            })
            .catch(error => {
                console.log('error: ', error);
            });
    }
    
    handleClickAddCash(){
        const evt = new ShowToastEvent({
            title: 'Warning!',
            message: 'Insufficient balance',
            variant: 'error',
            mode: 'dismissable'
        });
        this.dispatchEvent(evt);

        const modal = this.template.querySelector("c-wallet-modal");
        modal.idRecord = this.idRecord;
        modal.show();
    }

    navigateToObjectPal() {
        // Navigate to the Account home page
        this[NavigationMixin.Navigate]({
            type: 'standard__navItemPage',
            attributes: {
                apiName: 'Pals'
            }
        });
    }


}