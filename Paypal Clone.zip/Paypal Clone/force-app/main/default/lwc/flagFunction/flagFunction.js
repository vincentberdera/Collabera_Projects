import { LightningElement, api } from 'lwc';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import getPassbook from '@salesforce/apex/PaypalRecords.fetchPassobookRecord2';
import DebitCreditUsers from '@salesforce/apex/PaypalRecords.DebitCredtUsers';

export default class FlagFunction extends LightningElement {
    @api recordId;
    @api passbookId;
    @api venderName;
    @api userId;
    @api amount;
    @api cancelled;
 
    @api invoke(){
    console.log(this.recordId);
    getPassbook({'recordId':this.recordId}).then(res=>{
        if(res){
            res.forEach(row => {
                this.passbookId = row.Id;
                this.venderName = row.Name;
                this.userId = row.User__c;
                this.amount = row.Amount__c;
                this.cancelled = row.isCancelled__c;
                console.log(this.passbookId);
                console.log(this.venderName);
                console.log(this.userId);
                console.log(this.amount);
            });
            if(this.cancelled != true){
                DebitCreditUsers({
                    passbookId:this.passbookId,
                    walletId1:this.userId,
                    walletId2:this.venderName,
                    AmountToTransfer:this.amount
                }).then(()=>{
                    
                }).catch((error)=>{
                    this.errorMessage = error;
                    console.log('unable to update the record'+JSON.stringify(this.errorMessage));
                })
            }
            else{
                const evt = new ShowToastEvent({
                    title: 'Unseccessfull!',
                    message: 'You already cancelled this transaction',
                    variant: 'error',
                    mode: 'dismissable'
                });
                this.dispatchEvent(evt);
            }
            
        }
    })
    
   }

}