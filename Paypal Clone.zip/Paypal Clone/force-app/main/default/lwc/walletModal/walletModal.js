import { LightningElement, api } from 'lwc';
import AMOUNT from '@salesforce/schema/Wallet__c.Balance__c';
import getWallet from '@salesforce/apex/PaypalRecords.AddMoney';
import {ShowToastEvent} from 'lightning/platformShowToastEvent';
import { NavigationMixin } from 'lightning/navigation';

export default class WalletModal extends NavigationMixin(LightningElement) {

    showModal=false;
    objectName = 'Wallet__c';
    balance = AMOUNT;


    @api idRecord;

    @api show(){
        this.showModal = true;
    }

    handleDialogClose(){
        this.showModal = false;
    }

    handleCancelEditForm()
    {
        this.showModal = false;
    }

    handleSaveEditForm(){
        const evt = new ShowToastEvent({
            title: 'Success!',
            message: 'Transaction Success!',
            variant: 'success',
            mode: 'dismissable'
        });
        this.dispatchEvent(evt);
        getWallet({
            walletId1:this.idRecord,
            AmountToTransfer:this.template.querySelector("[data-field='Balance__c']").value
        }).then(()=>{
            
        }).catch((error)=>{
            this.errorMessage = error;
            console.log('unable to update the record'+JSON.stringify(this.errorMessage));
        })
        this.showModal = false;
        this.reloadPage();
    }

    reloadPage() {
        // Navigate to the Account home page
        this[NavigationMixin.Navigate]({
            "type": "standard__webPage",
            "attributes": {
                "url": "https://paypalclonecompany-dev-ed.lightning.force.com/lightning/n/Wallet"
            }
        });
    }

}