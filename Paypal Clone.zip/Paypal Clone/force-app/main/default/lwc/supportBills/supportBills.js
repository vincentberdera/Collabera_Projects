import { LightningElement } from 'lwc';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import {refreshApex} from '@salesforce/apex';
import { NavigationMixin } from 'lightning/navigation';
import getBillsRecords from '@salesforce/apex/PaypalRecords.fetchBillsRecordforAdmin';

const cols = [
    {
        label:'Name',
        fieldName: 'Name',
        type: 'text'
    },
    {
        label:'Category',
        fieldName: 'Category',
        type: 'text'
    },
    {
        label:'Amount',
        fieldName: 'Amount',
        type: 'currency'
    },
    {
        label:'Offer Applied',
        fieldName: 'OfferApplied',
        type: 'percent'
    },
    {
        label:'Pay Before',
        fieldName: 'PayBefore',
        type: 'date'
    },
    {
        label:'Paid',
        fieldName: 'Paid',
        type: 'text'
    },
    {
        label:'Successful',
        fieldName: 'Successful',
        type: 'text'
    },
    {
        type:"button",
        fixedWidth: 150,
        label:'Action',
        typeAttributes: {
            label: 'Edit',
            value: 'Id',
            name: 'edit',
            variant: 'success'
        }
    }
]

export default class SupportBills extends NavigationMixin(LightningElement) {

    columns = cols;
    result;
    error;

    connectedCallback(){
        this.handleBillsData();
    }

    handleBillsData(){
        getBillsRecords({}).then(res=>{
            let finalChange=[];
            res.forEach(row=>{
                let objectStruct = {};
                objectStruct.Id = row.Id;
                objectStruct.Name = row.Name;
                objectStruct.Location = row.Location__c;
                objectStruct.Category = row.Category__c;
                objectStruct.Amount = row.Amount__c;
                objectStruct.OfferApplied = row.Offer_Applied__c/100;
                
                objectStruct.PayBefore = row.Pay_Before__c;
                objectStruct.Paid = row.Paid__c;
                objectStruct.Successful = row.Successful__c;
                objectStruct.ForUser = row.For_User__r.Name;
                finalChange.push(objectStruct);
            })
            this.result = finalChange;
        }).catch(err => {
            this.error = err;
        })
    }

    handleAddBills(){
        const modal = this.template.querySelector("c-bills-modal");
        modal.addRecord=true;
        modal.show();
    }

    navigateToEditBills(event){
        const modal = this.template.querySelector("c-bills-modal");
        modal.passedId = event.detail.row.Id;
        modal.addRecord=false;
        modal.show();
    }
}