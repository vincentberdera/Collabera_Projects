import { LightningElement } from 'lwc';
import USER from '@salesforce/schema/Card__c.Name__c';
import CARD_NO from '@salesforce/schema/Card__c.Card_No__c';
import CCV from '@salesforce/schema/Card__c.CCV__c';
import EXPIRY_DATE from '@salesforce/schema/Card__c.Expiry_Date__c';
import checkuser from '@salesforce/apex/PaypalRecords.checkUserforWallet';
import getCardRecords from '@salesforce/apex/PaypalRecords.fetchCardRecord';

export default class CardPage extends LightningElement {

    fields = [USER, CARD_NO, CCV, EXPIRY_DATE];

    isShow;
    ownerName;
    cardNumber;
    totalSpend;

    connectedCallback(){
        this.checkuser();
    }

    checkuser(){
        checkuser({})
            .then(result => {
                console.log(result);
                this.isShow = result;
                if(this.isShow==true){
                    this.handleCardRecords();
                }
            })
            .catch(error => {
                console.log('error: ', error);
            });
    }

    handleCardRecords(){
        console.log("result");
        getCardRecords({})
            .then(result => {
                result.forEach(row => {
                    this.ownerName = row.Name__r.Name;
                    const last4Str = String(row.Card_No__c).slice(-4);
                    this.cardNumber = last4Str;
                    this.totalSpend = row.Total_Spend__c;

                })
                console.log(result);
            })
            .catch(error => {
                console.log('error: ', error);
            });
    }

}