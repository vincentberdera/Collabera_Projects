import { LightningElement, api } from 'lwc';
import { NavigationMixin } from 'lightning/navigation';
import openQuotation from '@salesforce/apex/PBALWC.openQuotation';

export default class OpenQuote extends NavigationMixin(LightningElement) {
    @api recordId;
    @api quoteId;
 
    @api invoke(){
    console.log(this.recordId);
    openQuotation({'quotationId':this.recordId}).then(res=>{
        if(res){
            res.forEach(row => {
                this.quoteId = row.Id;
                this.handleNavigation();
            });
        }
    })
    
   }

   handleNavigation(){
    this[NavigationMixin.Navigate]({
        type: 'standard__recordPage',
        attributes: {
            recordId: this.quoteId,
            actionName: 'view'
        }
    });
   }
}