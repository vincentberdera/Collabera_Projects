import { LightningElement } from 'lwc';
import getProperty from '@salesforce/apex/PBALWC.fetchProperty';
import getPropertyBooking from '@salesforce/apex/PBALWC.fetchPropertyBooking';
import getQuotation from '@salesforce/apex/PBALWC.fetchQuotation';
import getCustomer from '@salesforce/apex/PBALWC.fetchCustomer';

const cols1 = [
    {
        label: 'Property #',
        fieldName: 'PropertyURL',
        type:'url',
        typeAttributes:{
            label:{
                fieldName:'PropertyNo'
            }
        }
    },
    {
        label: 'Property Name',
        fieldName: 'PropertyURL',
        type:'url',
        typeAttributes:{
            label:{
                fieldName:'PropertyName'
            }
        }
    },
    {label: 'Area', fieldName: 'Area', type:'text'},
    {label: 'State', fieldName: 'State', type:'text'},
    {label: 'District', fieldName: 'District', type:'text'},
    {label: 'Type', fieldName: 'Type', type:'text'},
    {label: 'Storey', fieldName: 'Storey', type:'number'},
    {label: 'Built On', fieldName: 'BuiltOn', type:'date'},
    {label: 'PropertyAge', fieldName: 'PropertyAge', type:'number'}
];

const cols2 = [
    {
        label: 'Booking Reference',
        fieldName: 'BookingReferenceURL2',
        type:'url',
        typeAttributes:{
            label:{
                fieldName:'BookingReference2'
            }
        }
    },
    {
        label: 'Property Name',
        fieldName: 'PropertyURL2',
        type:'url',
        typeAttributes:{
            label:{
                fieldName:'PropertyName2'
            }
        }
    },
    {
        label: 'Customer Name',
        fieldName: 'CustomerURL2',
        type:'url',
        typeAttributes:{
            label:{
                fieldName:'CustomerName2'
            }
        }
    },
    {label: 'Status', fieldName: 'Status', type:'text'},
    {label: 'Actual Price', fieldName: 'ActualPrice', type:'currency'},
    {label: 'Quoted Price', fieldName: 'QuotedPrice', type:'currency'},
    {label: 'Acquire Property By', fieldName: 'AcquirePropertyBy', type:'date'}
];

const cols3 = [
    {
        label: 'Quotation No',
        fieldName: 'QuotationURL',
        type:'url',
        typeAttributes:{
            label:{
                fieldName:'QuotationNo'
            }
        }
    },
    {
        label: 'Booking Ref',
        fieldName: 'BookingURL3',
        type:'url',
        typeAttributes:{
            label:{
                fieldName:'BookingRef3'
            }
        }
    },
    {
        label: 'Property Name',
        fieldName: 'PropertyURL3',
        type:'url',
        typeAttributes:{
            label:{
                fieldName:'PropertyName3'
            }
        }
    },
    {label: 'Property Type', fieldName: 'PropertyType', type:'text'},
    {
        label: 'Customer Name',
        fieldName: 'CustomerURL3',
        type:'url',
        typeAttributes:{
            label:{
                fieldName:'CustomerName3'
            }
        }
    },
    {label: 'Customer Email', fieldName: 'CustomerEmail', type:'email'},
    {label: 'Acquire Property By', fieldName: 'AcquirePropertyBy3', type:'date'},
    {label: 'Price', fieldName: 'Price3', type:'currency'}
];

const cols4 = [
    {
        label: 'User',
        fieldName: 'UserURL',
        type:'url',
        typeAttributes:{
            label:{
                fieldName:'UserName'
            }
        }
    },
    {
        label: 'Customer Name',
        fieldName: 'CustomerURL4',
        type:'url',
        typeAttributes:{
            label:{
                fieldName:'CustomerName4'
            }
        }
    },
    {label: 'Aadhar', fieldName: 'Aadhar', type:'text'},
    {label: 'PAN', fieldName: 'PAN', type:'text'},
    {label: 'State', fieldName: 'State4', type:'text'},
    {label: 'District', fieldName: 'District4', type:'text'},
    {label: 'Email', fieldName: 'Email', type:'email'},
    {label: 'Phone', fieldName: 'Phone', type:'phone'},
];

export default class SearchRecords extends LightningElement {

    searchKey;

    columns1 = cols1;
    result1;
    error1;
    
    columns2 = cols2;
    result2;
    error2;
    
    columns3 = cols3;
    result3;
    error3;
    
    columns4 = cols4;
    result4;
    error4;

    handleKeys(e){
        this.searchKey = e.target.value;
        this.handlePropertyData();
        this.handlePropertyBookingData();
        this.handleQuotationData();
        this.handleCustomerData();
    }

    handlePropertyData(){
        getProperty({'Search':this.searchKey}).then(res => {
            if(this.searchKey != ''){               
                let finalChange=[];
                res.forEach(row=>{
                    let objectStruct = {};
                    objectStruct.Id = row.Id;
                    objectStruct.PropertyNo = row.Property__c;
                    objectStruct.PropertyName = row.Name;
                    objectStruct.Area = row.Area__c;
                    objectStruct.State = row.State__c;
                    objectStruct.District = row.District__c;
                    objectStruct.Type = row.Type__c;
                    objectStruct.Storey = row.Storey__c;
                    objectStruct.BuiltOn = row.Built_On__c;
                    objectStruct.PropertyAge = row.Property_Age_Years__c;
                    objectStruct.PropertyURL = 'https://dummycompany6-dev-ed.lightning.force.com/lightning/r/Property__c/'+row.Id+'/view';
                    finalChange.push(objectStruct);
                })
                this.result1 = finalChange;
            }
            else{
                let finalChange=[];
                this.result1 = finalChange;
            }
        }).catch(err=>{
            this.error1 = err;
        })
    }

    handlePropertyBookingData(){
        getPropertyBooking({'Search':this.searchKey}).then(res => {
            if(this.searchKey != ''){               
                let finalChange=[];
                res.forEach(row=>{
                    let objectStruct = {};
                    objectStruct.Id = row.Id;
                    objectStruct.BookingReference2 = row.Name;
                    objectStruct.PropertyName2 = row.Property__r.Name;
                    objectStruct.CustomerName2 = row.Customer__r.Name;
                    objectStruct.Status = row.Status__c;
                    objectStruct.ActualPrice = row.Actual_Price__c;
                    objectStruct.QuotedPrice = row.Quoted_Price__c;
                    objectStruct.AcquirePropertyBy = row.Acquire_Property_By__c;
                    objectStruct.BookingReferenceURL2 = 'https://dummycompany6-dev-ed.lightning.force.com/lightning/r/Property_Booking__c/'+row.Id+'/view';
                    objectStruct.PropertyURL2 = 'https://dummycompany6-dev-ed.lightning.force.com/lightning/r/Property__c/'+row.Property__c+'/view';
                    objectStruct.CustomerURL2 = 'https://dummycompany6-dev-ed.lightning.force.com/lightning/r/Customer__c/'+row.Customer__c+'/view';
                    finalChange.push(objectStruct);
                })
                this.result2 = finalChange;
            }
            else{
                let finalChange=[];
                this.result2 = finalChange;
            }
        }).catch(err=>{
            this.error2 = err;
        })
    }

    handleQuotationData(){
        getQuotation({'Search':this.searchKey}).then(res => {
            if(this.searchKey != ''){               
                let finalChange=[];
                res.forEach(row=>{
                    let objectStruct = {};
                    objectStruct.Id = row.Id;
                    objectStruct.QuotationNo = row.Name;
                    objectStruct.BookingRef3 = row.Booking_Ref__r.Name;
                    objectStruct.PropertyName3 = row.Property_Name__c;
                    objectStruct.PropertyType = row.Property_Type__c;
                    objectStruct.CustomerName3 = row.Customer_Name__c;
                    objectStruct.CustomerEmail = row.Customer_Email__c;
                    objectStruct.AcquirePropertyBy3 = row.Acquire_Property_By__c;
                    objectStruct.Price3 = row.Price__c ;
                    objectStruct.QuotationURL = 'https://dummycompany6-dev-ed.lightning.force.com/lightning/r/Quotation__c/'+row.Id+'/view';
                    objectStruct.BookingURL3 = 'https://dummycompany6-dev-ed.lightning.force.com/lightning/r/Property_Booking__c/'+row.Booking_Ref__c+'/view';
                    objectStruct.PropertyURL3 = 'https://dummycompany6-dev-ed.lightning.force.com/lightning/r/Property__c/'+row.Booking_Ref__r.Property__c+'/view';
                    objectStruct.CustomerURL3 = 'https://dummycompany6-dev-ed.lightning.force.com/lightning/r/Customer__c/'+row.Booking_Ref__r.Customer__c+'/view';
                    finalChange.push(objectStruct);
                })
                this.result3 = finalChange;
            }
            else{
                let finalChange=[];
                this.result3 = finalChange;
            }
        }).catch(err=>{
            this.error3 = err;
        })
    }

    handleCustomerData(){
        getCustomer({'Search':this.searchKey}).then(res => {
            if(this.searchKey != ''){               
                let finalChange=[];
                res.forEach(row=>{
                    let objectStruct = {};
                    objectStruct.Id = row.Id;
                    objectStruct.UserName = row.User__r.Name;
                    objectStruct.CustomerName4 = row.Name;
                    objectStruct.Aadhar = row.Aadhar__c;
                    objectStruct.PAN = row.PAN__c;
                    objectStruct.State4 = row.State__c;
                    objectStruct.District4 = row.District__c;
                    objectStruct.Email = row.Email__c;
                    objectStruct.Phone = row.Phone__c ;
                    objectStruct.UserURL = 'https://dummycompany6-dev-ed.lightning.force.com/lightning/r/User/'+row.User__c+'/view';
                    objectStruct.CustomerURL4 = 'https://dummycompany6-dev-ed.lightning.force.com/lightning/r/Customer__c/'+row.Id+'/view';
                    finalChange.push(objectStruct);
                })
                this.result4 = finalChange;
            }
            else{
                let finalChange=[];
                this.result4 = finalChange;
            }
        }).catch(err=>{
            this.error4 = err;
        })
    }

    
}