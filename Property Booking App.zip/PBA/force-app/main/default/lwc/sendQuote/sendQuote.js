import { LightningElement } from 'lwc';

export default class SendQuote extends LightningElement {}