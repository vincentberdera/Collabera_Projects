import { LightningElement, api } from 'lwc';
import { NavigationMixin } from 'lightning/navigation';
import checkUser from '@salesforce/apex/UserRender.checkUser';

export default class DisplayRecords extends NavigationMixin(LightningElement) {
        
    userProfile;
    carShow = false;
    accountShow = false;
    contactShow = false;
    carModelShow = false;
    campaignShow = false;
    carBookingShow = false;
    caseShow = false;
    leadShow = false;

    handleKeys(e){
        this.searchKey = e.target.value;
    }

    connectedCallback(){
        checkUser().then(result => {
            this.userProfile = result;
            if(this.userProfile === 'System Administrator'){
                this.leadsShow = true;
                this.accountShow = true;
                this.contactShow = true;
                this.carShow = true;
                this.carModelShow = true;
                this.campaignShow = true;
                this.carBookingShow = true;
                this.caseShow = true;
            }
            else if(this.userProfile === "Company Executives"){
                this.leadsShow = false;
                this.accountShow = false;
                this.contactShow = false;
                this.carShow = false;
                this.carModelShow = false;
                this.campaignShow = false;
                this.carBookingShow = false;
                this.caseShow = false;
            }
            else if(this.userProfile === "Factory Executives"){
                this.leadsShow = false;
                this.accountShow = false;
                this.contactShow = false;
                this.carShow = false;
                this.carModelShow = true;
                this.campaignShow = false;
                this.carBookingShow = false;
                this.caseShow = false;
            }
            else if(this.userProfile === "Quality Analysts"){
                this.leadsShow = false;
                this.accountShow = false;
                this.contactShow = false;
                this.carShow = false;
                this.carModelShow = false;
                this.campaignShow = false;
                this.carBookingShow = false;
                this.caseShow = false;
            }
            else if(this.userProfile === "Sales Executives"){
                this.leadsShow = true;
                this.accountShow = true;
                this.contactShow = true;
                this.carShow = false;
                this.carModelShow = false;
                this.campaignShow = false;
                this.carBookingShow = false;
                this.caseShow = false;
            }
            else if(this.userProfile === "Digital Marketers"){
                this.leadsShow = false;
                this.accountShow = false;
                this.contactShow = false;
                this.carShow = false;
                this.carModelShow = false;
                this.campaignShow = true;
                this.carBookingShow = false;
                this.caseShow = false;
            }
            else if(this.userProfile === "Car Dealers"){
                this.leadsShow = true;
                this.accountShow = true;
                this.contactShow = true;
                this.carShow = false;
                this.carModelShow = false;
                this.campaignShow = false;
                this.carBookingShow = false;
                this.caseShow = false;
            }
            else if(this.userProfile === "Customer Service Representatives"){
                this.leadsShow = false;
                this.accountShow = false;
                this.contactShow = false;
                this.carShow = false;
                this.carModelShow = false;
                this.campaignShow = false;
                this.carBookingShow = false;
                this.caseShow = true;
            }
        })
        .catch(error => {
            this.userProfile = error;
        });
    }   

}