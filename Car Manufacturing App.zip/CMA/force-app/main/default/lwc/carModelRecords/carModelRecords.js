import { LightningElement, api } from 'lwc';
import { NavigationMixin } from 'lightning/navigation';
import checkUser from '@salesforce/apex/UserRender.checkUser';
import getCarModel from '@salesforce/apex/UserRender.fetchCarModel';
import getCarModelFE from '@salesforce/apex/UserRender.fetchCarModelForFE';
import getCarModelQA from '@salesforce/apex/UserRender.fetchCarModelForQA';
import getCarModelDM from '@salesforce/apex/UserRender.fetchCarModelForDM';
import getCarModelSE from '@salesforce/apex/UserRender.fetchCarModelForSE';

const col2 = [
    {
        label: 'Name',
        fieldName: 'NameUrl2',
        type:'url',
        typeAttributes:{
            label:{
                fieldName:'Name2'
            }
        }
    },
    {
        label: 'Manufacturer',
        fieldName: 'Manufacturer2',
        type: 'text'
    },
    {
        label: 'Seating Capacity',
        fieldName: 'SeatingCapacity2',
        type: 'number'
    },
    {
        label: 'Dimension',
        fieldName: 'Dimension',
        type: 'text'
    },
    {
        label: 'Engine Type',
        fieldName: 'EngineType',
        type: 'text'
    },
    {
        label: 'Engine Displacement (cc)',
        fieldName: 'EngineDisplacement',
        type: 'number'
    },
    {
        label: 'Fuel Type',
        fieldName: 'FuelType',
        type: 'text'
    },
    {
        label: 'Fuel Capacity',
        fieldName: 'FuelCapacity',
        type: 'number'
    },
    {
        label: 'Price',
        fieldName: 'Price',
        type: 'currency'
    },
    {
        label: 'Stage',
        fieldName: 'Stage2',
        type: 'text'
    },
    {type: "button",
        typeAttributes: {  
        label: 'Edit',  
        name: 'Edit',  
        title: 'Edit',  
        disabled: false,  
        value: 'Id',  
        iconPosition: 'left'  
    }}
       
]

const CSS_CLASS = "modal-hidden";

export default class CarModelRecords extends NavigationMixin(LightningElement) {
    
    userProfile;

    showModal=false;

    columns2 = col2;
    result2;
    error2;

    handleKeys(e){
        this.searchKey = e.target.value;
    }

    connectedCallback(){
        this.handleCarModelData();
    }

    @api show(){
        this.showModal = true;
    }

    handleDialogClose(){
        this.showModal = false;
    }
    
    navigateToNewCarModel() {
        this[NavigationMixin.Navigate]({
            type: 'standard__objectPage',
            attributes: {
                objectApiName: 'Car_Model__c',
                actionName: 'new'
            }
        })
    }


    handleCarModelData(){
        checkUser().then(result => {
            this.userProfile = result;
            if(this.userProfile === 'System Administrator' || this.userProfile === "Company Executives"){
                getCarModel({'Search':this.searchKey}).then( res =>{
                    //function(res)
                    if(res)
                    {
                        let finalChange=[];
                        res.forEach(row =>{
                            let objectStruct = {};
                            objectStruct.Id = row.Id;
                            objectStruct.Name2 = row.Name;
                            objectStruct.Manufacturer2 = row.Car__r.Manufacturer__c;
                            objectStruct.SeatingCapacity2 = row.Seating_Capacity__c;
                            objectStruct.Dimension = row.Width__c + "x" + row.Length__c + "x" + row.Height__c;
                            objectStruct.EngineType = row.Engine_Type__c;
                            objectStruct.EngineDisplacement = row.Engine_Displacement__c;
                            objectStruct.FuelType = row.Fuel_Type__c;
                            objectStruct.FuelCapacity = row.Fuel_Capacity__c;
                            objectStruct.Price = row.Price__c;
                            objectStruct.Stage2 = row.Stage__c;
                            objectStruct.NameUrl2 = 'https://carmanufacturer-dev-ed.lightning.force.com/lightning/r/Car_Model__c/'+row.Id+'/view';
                            finalChange.push(objectStruct);
                        })
                        this.result2 = finalChange;
        
                    }
                }).catch(err =>{
                    this.error2 = err;
                })
                
            }
            else if(this.userProfile === "Factory Executives"){
                getCarModelFE({'Search':this.searchKey}).then( res =>{
                    //function(res)
                    if(res)
                    {
                        let finalChange=[];
                        res.forEach(row =>{
                            let objectStruct = {};
                            objectStruct.Id = row.Id;
                            objectStruct.Name2 = row.Name;
                            objectStruct.Manufacturer2 = row.Car__r.Manufacturer__c;
                            objectStruct.SeatingCapacity2 = row.Seating_Capacity__c;
                            objectStruct.Dimension = row.Width__c + "x" + row.Length__c + "x" + row.Height__c;
                            objectStruct.EngineType = row.Engine_Type__c;
                            objectStruct.EngineDisplacement = row.Engine_Displacement__c;
                            objectStruct.FuelType = row.Fuel_Type__c;
                            objectStruct.FuelCapacity = row.Fuel_Capacity__c;
                            objectStruct.Price = row.Price__c;
                            objectStruct.Stage2 = row.Stage__c;
                            objectStruct.NameUrl2 = 'https://carmanufacturer-dev-ed.lightning.force.com/lightning/r/Car_Model__c/'+row.Id+'/view';
                            finalChange.push(objectStruct);
                        })
                        this.result2 = finalChange;
        
                    }
                }).catch(err =>{
                    this.error2 = err;
                })                
            }
            else if(this.userProfile === "Quality Analysts"){
                getCarModelQA({'Search':this.searchKey}).then( res =>{
                    //function(res)
                    if(res)
                    {
                        let finalChange=[];
                        res.forEach(row =>{
                            let objectStruct = {};
                            objectStruct.Id = row.Id;
                            objectStruct.Name2 = row.Name;
                            objectStruct.Manufacturer2 = row.Car__r.Manufacturer__c;
                            objectStruct.SeatingCapacity2 = row.Seating_Capacity__c;
                            objectStruct.Dimension = row.Width__c + "x" + row.Length__c + "x" + row.Height__c;
                            objectStruct.EngineType = row.Engine_Type__c;
                            objectStruct.EngineDisplacement = row.Engine_Displacement__c;
                            objectStruct.FuelType = row.Fuel_Type__c;
                            objectStruct.FuelCapacity = row.Fuel_Capacity__c;
                            objectStruct.Price = row.Price__c;
                            objectStruct.Stage2 = row.Stage__c;
                            objectStruct.NameUrl2 = 'https://carmanufacturer-dev-ed.lightning.force.com/lightning/r/Car_Model__c/'+row.Id+'/view';
                            finalChange.push(objectStruct);
                        })
                        this.result2 = finalChange;
        
                    }
                }).catch(err =>{
                    this.error2 = err;
                })                 
            }
            else if(this.userProfile === "Sales Executives"){
                getCarModelSE({'Search':this.searchKey}).then( res =>{
                    //function(res)
                    if(res)
                    {
                        let finalChange=[];
                        res.forEach(row =>{
                            let objectStruct = {};
                            objectStruct.Id = row.Id;
                            objectStruct.Name2 = row.Name;
                            objectStruct.Manufacturer2 = row.Car__r.Manufacturer__c;
                            objectStruct.SeatingCapacity2 = row.Seating_Capacity__c;
                            objectStruct.Dimension = row.Width__c + "x" + row.Length__c + "x" + row.Height__c;
                            objectStruct.EngineType = row.Engine_Type__c;
                            objectStruct.EngineDisplacement = row.Engine_Displacement__c;
                            objectStruct.FuelType = row.Fuel_Type__c;
                            objectStruct.FuelCapacity = row.Fuel_Capacity__c;
                            objectStruct.Price = row.Price__c;
                            objectStruct.Stage2 = row.Stage__c;
                            objectStruct.NameUrl2 = 'https://carmanufacturer-dev-ed.lightning.force.com/lightning/r/Car_Model__c/'+row.Id+'/view';
                            finalChange.push(objectStruct);
                        })
                        this.result2 = finalChange;
        
                    }
                }).catch(err =>{
                    this.error2 = err;
                })   
                
            }
            else if(this.userProfile === "Digital Marketers"){
                getCarModelDM({'Search':this.searchKey}).then( res =>{
                    //function(res)
                    if(res)
                    {
                        let finalChange=[];
                        res.forEach(row =>{
                            let objectStruct = {};
                            objectStruct.Id = row.Id;
                            objectStruct.Name2 = row.Name;
                            objectStruct.Manufacturer2 = row.Car__r.Manufacturer__c;
                            objectStruct.SeatingCapacity2 = row.Seating_Capacity__c;
                            objectStruct.Dimension = row.Width__c + "x" + row.Length__c + "x" + row.Height__c;
                            objectStruct.EngineType = row.Engine_Type__c;
                            objectStruct.EngineDisplacement = row.Engine_Displacement__c;
                            objectStruct.FuelType = row.Fuel_Type__c;
                            objectStruct.FuelCapacity = row.Fuel_Capacity__c;
                            objectStruct.Price = row.Price__c;
                            objectStruct.Stage2 = row.Stage__c;
                            objectStruct.NameUrl2 = 'https://carmanufacturer-dev-ed.lightning.force.com/lightning/r/Car_Model__c/'+row.Id+'/view';
                            finalChange.push(objectStruct);
                        })
                        this.result2 = finalChange;
        
                    }
                }).catch(err =>{
                    this.error2 = err;
                })                    
            }
            else if(this.userProfile === "Car Dealers"){

            }
            else if(this.userProfile === "Customer Service Representatives"){

            }
        })
        .catch(error => {
            this.userProfile = error;
        })
    }

    handleShowModal(event){
        const modal = this.template.querySelector("c-child-modal");
        modal.idPassed = event.detail.row.Id;
        modal.show();
    }


}