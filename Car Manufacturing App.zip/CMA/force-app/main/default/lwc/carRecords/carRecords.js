import { LightningElement } from 'lwc';
import { NavigationMixin } from 'lightning/navigation';
import getCar from '@salesforce/apex/UserRender.fetchCar';

const col1 = [
    {
        label: 'Name',
        fieldName: 'NameUrl1',
        type:'url',
        typeAttributes:{
            label:{
                fieldName:'Name1'
            }
        }
    },
    {
        label: 'Manufacturer',
        fieldName: 'Manufacturer',
        type: 'text'
    },
    {
        label: 'Type',
        fieldName: 'Type1',
        type: 'text'
    },
    {
        label: 'Seating Capacity',
        fieldName: 'SeatingCapacity1',
        type: 'number'
    },
    {type: "button",
        typeAttributes: {  
        label: 'Edit',  
        name: 'Edit',  
        title: 'Edit',  
        disabled: false,  
        value: 'Id',  
        iconPosition: 'left'  
    }}
]

export default class CarRecords extends NavigationMixin(LightningElement) {

    columns1 = col1;
    result1;
    error1;

    handleKeys(e){
        this.searchKey = e.target.value;
    }

    connectedCallback(){
        this.handleCarData();
    }
    

    navigateToNewCar() {
        this[NavigationMixin.Navigate]({
            type: 'standard__objectPage',
            attributes: {
                objectApiName: 'Car__c',
                actionName: 'new'
            }
        })
    }


    handleCarData(){
        getCar({'Search':this.searchKey}).then( res =>{
            //function(res)
            if(res)
            {
                let finalChange=[];
                res.forEach(row =>{
                    let objectStruct = {};
                    objectStruct.Id = row.Id;
                    objectStruct.Name1 = row.Name;
                    objectStruct.Manufacturer = row.Manufacturer__c;
                    objectStruct.Type1 = row.Type__c;
                    objectStruct.SeatingCapacity1 = row.Seating_Capacity__c;
                    objectStruct.NameUrl1 = 'https://carmanufacturer-dev-ed.lightning.force.com/lightning/r/Car__c/'+row.Id+'/view';
                    finalChange.push(objectStruct);
                })
                this.result1 = finalChange;

            }
        }).catch(err =>{
            this.error1 = err;
        })
    }

    callRowAction( event ) {  
        console.log(event.detail.row.Id);  
        const recId =  event.detail.row.Id;          
  
        this[NavigationMixin.Navigate]({  
            type: 'standard__recordPage',  
            attributes: {  
                recordId: recId,  
                objectApiName: 'Car_Booking__c',  
                actionName: 'edit'  
            }  
        })     
  
    }


}