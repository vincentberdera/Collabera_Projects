import { LightningElement } from 'lwc';
import { NavigationMixin } from 'lightning/navigation';
import getCampaign from '@salesforce/apex/UserRender.fetchCampaign';

const col6 = [
    {
        label: 'Campaign Name',
        fieldName: 'NameUrl6',
        type:'url',
        typeAttributes:{
            label:{
                fieldName:'Name6'
            }
        }
    },
    {
        label: 'Start Date',
        fieldName: 'StartDate6',
        type: 'date'
    },
    {
        label: 'End Date',
        fieldName: 'EndDate6',
        type: 'date'
    },
    {
        label: 'Budgeted Cost in Campaign',
        fieldName: 'BudgetedCostInCampaign',
        type: 'currency'
    },
    {
        label: 'Actual Cost in Campaign',
        fieldName: 'ActualCostInCampaign',
        type: 'currency'
    },
    {
        label: 'Type',
        fieldName: 'Type6',
        type: 'text'
    },
    {
        label: 'Status',
        fieldName: 'Status6',
        type: 'text'
    },
    {type: "button",
        typeAttributes: {  
        label: 'Edit',  
        name: 'Edit',  
        title: 'Edit',  
        disabled: false,  
        value: 'Id',  
        iconPosition: 'left'  
    }}
]

export default class CampaignRecords extends NavigationMixin(LightningElement) {

    columns6 = col6;
    result6;
    error6;

    handleKeys(e){
        this.searchKey = e.target.value;
    }

    connectedCallback(){
        this.handleCampaignData();
    }
    
    navigateToNewCampaigns() {
        this[NavigationMixin.Navigate]({
            type: 'standard__objectPage',
            attributes: {
                objectApiName: 'Campaign',
                actionName: 'new'
            }
        })
    }


    handleCampaignData(){
        getCampaign({'Search':this.searchKey}).then( res =>{
            //function(res)
            if(res)
            {
                let finalChange=[];
                res.forEach(row =>{
                    let objectStruct = {};
                    objectStruct.Id = row.Id;
                    objectStruct.Name6 = row.Name;
                    objectStruct.StartDate6 = row.StartDate;
                    objectStruct.EndDate6 = row.EndDate;
                    objectStruct.BudgetedCostInCampaign = row.BudgetedCost;
                    objectStruct.ActualCostInCampaign = row.ActualCost;
                    objectStruct.Type6 = row.Type;
                    objectStruct.Status6 = row.Status;
                    objectStruct.NameUrl6 = 'https://carmanufacturer-dev-ed.lightning.force.com/lightning/r/Campaign/'+row.Id+'/view';
                    finalChange.push(objectStruct);
                })
                this.result6 = finalChange;

            }
        }).catch(err =>{
            this.error6 = err;
        })
    }

    callRowAction( event ) {  
        console.log(event.detail.row.Id);  
        const recId =  event.detail.row.Id;          
  
        this[NavigationMixin.Navigate]({  
            type: 'standard__recordPage',  
            attributes: {  
                recordId: recId,  
                objectApiName: 'Campaign',  
                actionName: 'edit'  
            }  
        })     
  
    }


}