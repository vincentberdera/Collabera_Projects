import { LightningElement } from 'lwc';
import { NavigationMixin } from 'lightning/navigation';
import getCase from '@salesforce/apex/UserRender.fetchCase';

const col7 = [
    {
        label: 'Case Number',
        fieldName: 'CaseUrl7',
        type:'url',
        typeAttributes:{
            label:{
                fieldName:'CaseNumber'
            }
        }
    },
   {
        label: 'Contact Name',
        fieldName: 'ContactUrl7',
        type:'url',
        typeAttributes:{
            label:{
                fieldName:'ContactName7'
            }
        }
    },
    {
        label: 'Subject',
        fieldName: 'Subject7',
        type: 'text'
    },
    {
        label: 'Status',
        fieldName: 'Status7',
        type: 'text'
    },
    {
        label: 'Priority',
        fieldName: 'Priority',
        type: 'text'
    },
    {
        label: 'Data/Time Opened',
        fieldName: 'DateTimeOpened',
        type: 'datetime'
    },
    {type: "button",
        typeAttributes: {  
        label: 'Edit',  
        name: 'Edit',  
        title: 'Edit',  
        disabled: false,  
        value: 'Id',  
        iconPosition: 'left'  
    }}
]

export default class CaseRecords extends NavigationMixin(LightningElement) {

    columns7 = col7;
    result7;
    error7;

    handleKeys(e){
        this.searchKey = e.target.value;
    }

    connectedCallback(){
        this.handleCaseData();
    }
    
    navigateToNewCases() {
        this[NavigationMixin.Navigate]({
            type: 'standard__objectPage',
            attributes: {
                objectApiName: 'Case',
                actionName: 'new'
            }
        })
    }


    handleCaseData(){
        getCase({'Search':this.searchKey}).then( res =>{
            //function(res)
            if(res)
            {
                let finalChange=[];
                res.forEach(row =>{
                    let objectStruct = {};
                    objectStruct.Id = row.Id;
                    objectStruct.CaseNumber = row.CaseNumber;
                    objectStruct.ContactName7 = row.Contact.Name;
                    objectStruct.Subject7 = row.Subject;
                    objectStruct.Status7 = row.Status;
                    objectStruct.Priority = row.Priority;
                    objectStruct.DateTimeOpened = row.CreatedDate;
                    objectStruct.CaseUrl7 = 'https://carmanufacturer-dev-ed.lightning.force.com/lightning/r/Case/'+row.Id+'/view';
                    objectStruct.ContactUrl7 = 'https://carmanufacturer-dev-ed.lightning.force.com/lightning/r/Contact/'+row.ContactId+'/view';
                    finalChange.push(objectStruct);
                })
                this.result7 = finalChange;

            }
        }).catch(err =>{
            this.error7 = err;
        })
    }

    callRowAction( event ) {  
        console.log(event.detail.row.Id);  
        const recId =  event.detail.row.Id;          
  
        this[NavigationMixin.Navigate]({  
            type: 'standard__recordPage',  
            attributes: {  
                recordId: recId,  
                objectApiName: 'Car_Booking__c',  
                actionName: 'edit'  
            }  
        })     
  
    }


}