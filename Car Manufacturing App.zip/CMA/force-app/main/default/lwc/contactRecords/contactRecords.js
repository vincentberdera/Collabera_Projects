import { LightningElement } from 'lwc';
import { NavigationMixin } from 'lightning/navigation';
import getContact from '@salesforce/apex/UserRender.fetchContact';

const col5 = [
    {
        label: 'Name',
        fieldName: 'NameUrl5',
        type:'url',
        typeAttributes:{
            label:{
                fieldName:'Name5'
            }
        }
    },
   {
        label: 'Account Name',
        fieldName: 'AccountUrl5',
        type:'url',
        typeAttributes:{
            label:{
                fieldName:'AccountName5'
            }
        }
    },
    {
        label: 'Title',
        fieldName: 'Title',
        type: 'text'
    },
    {
        label: 'Phone',
        fieldName: 'Phone5',
        type: 'phone'
    },
    {
        label: 'Email',
        fieldName: 'Email5',
        type: 'email'
    },
    {type: "button",
        typeAttributes: {  
        label: 'Edit',  
        name: 'Edit',  
        title: 'Edit',  
        disabled: false,  
        value: 'Id',  
        iconPosition: 'left'  
    }}
]

export default class ContactRecords extends NavigationMixin(LightningElement) {

    columns5 = col5;
    result5;
    error5;

    handleKeys(e){
        this.searchKey = e.target.value;
    }

    connectedCallback(){
        this.handleContactData();
    }
    
    navigateToNewContacts() {
        this[NavigationMixin.Navigate]({
            type: 'standard__objectPage',
            attributes: {
                objectApiName: 'Contact',
                actionName: 'new'
            }
        })
    }


    handleContactData(){
        getContact({'Search':this.searchKey}).then( res =>{
            //function(res)
            if(res)
            {
                let finalChange=[];
                res.forEach(row =>{
                    let objectStruct = {};
                    objectStruct.Id = row.Id;
                    objectStruct.Name5 = row.Name;
                    objectStruct.AccountName5 = row.Account.Name;
                    objectStruct.Title = row.Title;
                    objectStruct.Phone5 = row.Phone;
                    objectStruct.Email5 = row.Email;
                    objectStruct.NameUrl5 = 'https://carmanufacturer-dev-ed.lightning.force.com/lightning/r/Account/'+row.Id+'/view';
                    objectStruct.AccountUrl5 = 'https://carmanufacturer-dev-ed.lightning.force.com/lightning/r/Contact/'+row.AccountId+'/view';
                    finalChange.push(objectStruct);
                })
                this.result5 = finalChange;

            }
        }).catch(err =>{
            this.error5 = err;
        })
    }

    callRowAction( event ) {  
        console.log(event.detail.row.Id);  
        const recId =  event.detail.row.Id;          
  
        this[NavigationMixin.Navigate]({  
            type: 'standard__recordPage',  
            attributes: {  
                recordId: recId,  
                objectApiName: 'Car_Booking__c',  
                actionName: 'edit'  
            }  
        })     
  
    }


}