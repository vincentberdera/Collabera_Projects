import { LightningElement, wire } from 'lwc';
import LAST_NAME from '@salesforce/schema/Lead.LastName';
import COMPANY from '@salesforce/schema/Lead.Company';
import checkUser from '@salesforce/apex/UserRender.checkUser';


export default class PartialRender extends LightningElement {    
    
    userProfile;
    fields = [LAST_NAME,COMPANY];
    leadsShow = false;
    accountShow = false;
    contactShow = false;
    carShow = false;
    carModelShow = false;
    campaignShow = false;
    carBookingShow = false;
    caseShow = false;

    connectedCallback(){
        checkUser().then(result => {
            this.userProfile = result;
            if(this.userProfile === 'System Administrator'){
                this.leadsShow = true;
                this.accountShow = true;
                this.contactShow = true;
                this.carShow = true;
                this.carModelShow = true;
                this.campaignShow = true;
                this.carBookingShow = true;
                this.caseShow = true;
            }
            else if(this.userProfile === "Company Executives"){
                this.leadsShow = false;
                this.accountShow = false;
                this.contactShow = false;
                this.carShow = false;
                this.carModelShow = false;
                this.campaignShow = false;
                this.carBookingShow = false;
                this.caseShow = false;
            }
            else if(this.userProfile === "Factory Executives"){
                this.leadsShow = false;
                this.accountShow = false;
                this.contactShow = false;
                this.carShow = false;
                this.carModelShow = true;
                this.campaignShow = false;
                this.carBookingShow = false;
                this.caseShow = false;
            }
            else if(this.userProfile === "Quality Analysts"){
                this.leadsShow = false;
                this.accountShow = false;
                this.contactShow = false;
                this.carShow = false;
                this.carModelShow = false;
                this.campaignShow = false;
                this.carBookingShow = false;
                this.caseShow = false;
            }
            else if(this.userProfile === "Sales Executives"){
                this.leadsShow = true;
                this.accountShow = true;
                this.contactShow = true;
                this.carShow = false;
                this.carModelShow = false;
                this.campaignShow = false;
                this.carBookingShow = false;
                this.caseShow = false;
            }
            else if(this.userProfile === "Digital Marketers"){
                this.leadsShow = false;
                this.accountShow = false;
                this.contactShow = false;
                this.carShow = false;
                this.carModelShow = false;
                this.campaignShow = true;
                this.carBookingShow = false;
                this.caseShow = false;
            }
            else if(this.userProfile === "Car Dealers"){
                this.leadsShow = true;
                this.accountShow = true;
                this.contactShow = true;
                this.carShow = false;
                this.carModelShow = false;
                this.campaignShow = false;
                this.carBookingShow = false;
                this.caseShow = false;
            }
            else if(this.userProfile === "Customer Service Representatives"){
                this.leadsShow = false;
                this.accountShow = false;
                this.contactShow = false;
                this.carShow = false;
                this.carModelShow = false;
                this.campaignShow = false;
                this.carBookingShow = false;
                this.caseShow = true;
            }
        })
        .catch(error => {
            this.userProfile = error;
        });        
    }
}