import { LightningElement, api, track } from 'lwc';
import sendEmailToController from '@salesforce/apex/UserRender.sendEmailToController'

import checkUser from '@salesforce/apex/UserRender.checkUser';
import CAR_BOOKING_ID from '@salesforce/schema/Car_Booking__c.Id';
import CAR_BOOKING_NAME from '@salesforce/schema/Car_Booking__c.Name';
import CAR_MODEL_NAME from '@salesforce/schema/Car_Booking__c.Car_Model__c';
import ACCOUNT from '@salesforce/schema/Car_Booking__c.Account__c';
import START_DATE from '@salesforce/schema/Car_Booking__c.Start_Date__c';
import END_DATE from '@salesforce/schema/Car_Booking__c.End_Date__c';
import PAYMENT_STATUS from '@salesforce/schema/Car_Booking__c.Payment_Status__c';
import STAGE from '@salesforce/schema/Car_Booking__c.Stage__c';
import checkOwner from '@salesforce/apex/UserRender.checkOwner';

import { updateRecord } from 'lightning/uiRecordApi';
import {ShowToastEvent} from 'lightning/platformShowToastEvent';

export default class CarBookingModal extends LightningElement {

    @track subject = 'Car Booking Status';
    @track body = '';
    @track toSend = '';

    showModal=false;
    objectName = 'Car_Booking__c';
    userProfile;

    idName;

    carModelName = CAR_MODEL_NAME;
    account = ACCOUNT;
    startDate = START_DATE;
    endDate = END_DATE;
    paymentStatus = PAYMENT_STATUS;
    stage = STAGE;

    ownerName;
    ownerEmail;

    result;
    error;


    @api idPassed;

    @api show(){
        this.showModal = true;
        checkOwner({'BookingId':this.idPassed}).then(res =>{
            if(res){
                res.forEach(row => {
                    this.ownerName = row.CreatedBy.Name;
                    this.ownerEmail = row.CreatedBy.Email;
                    this.idName = row.Name;
                    this.toSend = this.ownerEmail;

                })
            }
            console.log(this.ownerName);
            console.log(this.ownerEmail);
        }).catch(err =>{
            this.error = err;
        })
    }

    connectedCallback(){
        checkUser().then(result => {
            this.userProfile = result;
        })
        .catch(error => {
            this.userProfile = error;
        })
    }

    handleDialogClose(){
        this.showModal = false;
    }

    handleCancelEditForm()
    {
        this.showModal = false;
    }

    handleSaveEditForm()
    {
        const recordField = {};
        
        recordField[CAR_BOOKING_ID.fieldApiName] = this.idPassed;
        //recordField[CAR_BOOKING_NAME.fieldApiName] = this.idName;
       // recordField[CAR_MODEL_NAME.fieldApiName] = this.template.querySelector("[data-field='Car_Model__c']").value;
        recordField[ACCOUNT.fieldApiName] = this.template.querySelector("[data-field='Account__c']").value;
        recordField[START_DATE.fieldApiName] = this.template.querySelector("[data-field='Start_Date__c']").value;
        recordField[END_DATE.fieldApiName] = this.template.querySelector("[data-field='End_Date__c']").value;
        recordField[STAGE.fieldApiName] = this.template.querySelector("[data-field='Stage__c']").value;
        this.body = `Hello ${this.ownerName},<br/><br/>The car you booked is at "${recordField[STAGE.fieldApiName]}" stage.<br/><br/>Thank you.`;
        console.log(this.body);

        if(this.userProfile === 'System Administrator' || this.userProfile === "Company Executives" || this.userProfile === "Sales Executives" || this.userProfile === "Car Dealers" || this.userProfile === "Customer Service Representatives"){
            const recordInput ={
                fields:recordField
            }            
            console.log(recordInput);
            updateRecord(recordInput).then(() => {
                this.dispatchEvent(
                    new ShowToastEvent({
                        title: 'Success',
                        message: 'Car Booking Updated',
                        variant: 'success'
                    })
                );
                this.sendEmailAfterEvent();
                window.location.reload();
            })
            .catch(error => {
                console.log(error);
                this.dispatchEvent(
                    new ShowToastEvent({
                        title: 'Error updating record',
                        message: error.body.message,
                        variant: 'error'
                    })
                );
            });
            this.showModal = false;
        }   
        else{
            this.dispatchEvent(
                new ShowToastEvent({
                    title: 'Error updating record',
                    message: 'You don not have an access to edit Car Booking Details',
                    variant: 'error'
                })
            );
            this.showModal = false;
        }

        
    }

    
    sendEmailAfterEvent(){
        const recordInput = {body: this.body, toSend: this.toSend, subject: this.subject}  //You can send parameters
        sendEmailToController(recordInput)
        .then( () => {
            //If response is ok
        }).catch( error => {
            //If there is an error on response
        })

    }

}