import { LightningElement } from 'lwc';
import { NavigationMixin } from 'lightning/navigation';
import getAccount from '@salesforce/apex/UserRender.fetchAccount';

const col4 = [
    {
        label: 'Name',
        fieldName: 'NameUrl4',
        type:'url',
        typeAttributes:{
            label:{
                fieldName:'Name4'
            }
        }
    },
    {
        label: 'Site',
        fieldName: 'Site',
        type:'text'
    },
    {
        label: 'Billing Address',
        fieldName: 'BillingAddress',
        type: 'text'
    },
    {
        label: 'Phone',
        fieldName: 'Phone4',
        type: 'phone'
    },
    {
        label: 'Type',
        fieldName: 'Type',
        type: 'text'
    },
    {type: "button",
        typeAttributes: {  
        label: 'Edit',  
        name: 'Edit',  
        title: 'Edit',  
        disabled: false,  
        value: 'Id',  
        iconPosition: 'left'  
    }}
]

export default class AccountRecords extends NavigationMixin(LightningElement) {

    columns4 = col4;
    result4;
    error4;

    handleKeys(e){
        this.searchKey = e.target.value;
    }

    connectedCallback(){
        this.handleAccountData();
    }
    
    navigateToNewAccount() {
        this[NavigationMixin.Navigate]({
            type: 'standard__objectPage',
            attributes: {
                objectApiName: 'Account',
                actionName: 'new'
            }
        })
    }


    handleAccountData(){
        getAccount({'Search':this.searchKey}).then( res =>{
            //function(res)
            if(res)
            {
                let finalChange=[];
                res.forEach(row =>{
                    let objectStruct = {};
                    objectStruct.Id = row.Id;
                    objectStruct.Name4 = row.Name;
                    objectStruct.Site = row.Site;
                    objectStruct.BillingAddress = row.BillingAddress;
                    objectStruct.Phone4 = row.Phone;
                    objectStruct.Type = row.Type;
                    objectStruct.NameUrl4 = 'https://carmanufacturer-dev-ed.lightning.force.com/lightning/r/Account/'+row.Id+'/view';
                    finalChange.push(objectStruct);
                })
                this.result4 = finalChange;

            }
        }).catch(err =>{
            this.error4 = err;
        })
    }

    callRowAction( event ) {  
        console.log(event.detail.row.Id);  
        const recId =  event.detail.row.Id;          
  
        this[NavigationMixin.Navigate]({  
            type: 'standard__recordPage',  
            attributes: {  
                recordId: recId,  
                objectApiName: 'Account',  
                actionName: 'edit'  
            }  
        })     
  
    }



}