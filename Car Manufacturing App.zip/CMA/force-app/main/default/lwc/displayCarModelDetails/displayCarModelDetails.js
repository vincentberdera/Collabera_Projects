import { LightningElement, api, track } from 'lwc';

export default class DisplayCarModelDetails extends LightningElement {
@api carid = "None";
@track caridd;

    @api childMethod(event){
        //this.carId = this.template.querySelector('c-display-car').recordId;
        //console.log(this.template.querySelector('c-display-car').car);
        //this.carId = e.detail;
        console.log("This is car model Id"+event);
        this.carid = event;
    }

}