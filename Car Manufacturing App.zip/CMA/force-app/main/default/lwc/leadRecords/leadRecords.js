import { LightningElement } from 'lwc';
import { NavigationMixin } from 'lightning/navigation';
import getLead from '@salesforce/apex/UserRender.fetchLead';

const col8 = [
    {
        label: 'Name',
        fieldName: 'NameUrl8',
        type:'url',
        typeAttributes:{
            label:{
                fieldName:'Name8'
            }
        }
    },
    {
        label: 'Title',
        fieldName: 'Title',
        type: 'text'
    },
    {
        label: 'Company',
        fieldName: 'Company',
        type: 'text'
    },
    {
        label: 'Phone',
        fieldName: 'Phone8',
        type: 'phone'
    },
    {
        label: 'Email',
        fieldName: 'Email8',
        type: 'email'
    },
    {
        label: 'Lead - Status',
        fieldName: 'Status8',
        type: 'text'
    }
]

export default class LeadRecords extends NavigationMixin(LightningElement) {

    columns8 = col8;
    result8;
    error8;

    handleKeys(e){
        this.searchKey = e.target.value;
    }

    connectedCallback(){
        this.handleLeadData();
    }

    navigateToLead() {
        this[NavigationMixin.Navigate]({
            type: 'standard__objectPage',
            attributes: {
                objectApiName: 'Lead',
                actionName: 'new'
            }
        })
    }


    handleLeadData(){
        getLead({'Search':this.searchKey}).then( res =>{
            //function(res)
            if(res)
            {
                let finalChange=[];
                res.forEach(row =>{
                    let objectStruct = {};
                    objectStruct.Name8 = row.Name;
                    objectStruct.Title = row.Title;
                    objectStruct.Company = row.Company;
                    objectStruct.Phone8 = row.Phone;
                    objectStruct.Email8 = row.Email;
                    objectStruct.Status8 = row.Status;
                    objectStruct.NameUrl8 = 'https://carmanufacturer-dev-ed.lightning.force.com/lightning/r/Lead/'+row.Id+'/view';
                    finalChange.push(objectStruct);
                })
                this.result8 = finalChange;

            }
        }).catch(err =>{
            this.error8 = err;
        })
    }


}