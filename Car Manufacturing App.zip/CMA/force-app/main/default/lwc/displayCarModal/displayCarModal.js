import { LightningElement, api } from 'lwc';
import CAR_MODEL from '@salesforce/schema/Car_Booking__c.Car_Model__c';
import ACCOUNT from '@salesforce/schema/Car_Booking__c.Account__c';
import START_DATE from '@salesforce/schema/Car_Booking__c.Start_Date__c';
import END_DATE from '@salesforce/schema/Car_Booking__c.End_Date__c';

import {ShowToastEvent} from 'lightning/platformShowToastEvent';

export default class DisplayCarModal extends LightningElement {
    showModal=false;
    objectName = 'Car_Booking__c';
    userProfile;

    @api carModel;

    fields = [CAR_MODEL, ACCOUNT, START_DATE, END_DATE];

    @api show(){
        this.showModal = true;
    }

    handleDialogClose() {
        this.showModal = false;
        }
        
    handleOnSuccess(event)
    {
        const toastEventSuccess =new ShowToastEvent({
            title: "Car created successfully!",
            variant:"success"
        })
        this.dispatchEvent(toastEventSuccess);
        this.handleDialogClose();
        window.location.reload();
    }
}