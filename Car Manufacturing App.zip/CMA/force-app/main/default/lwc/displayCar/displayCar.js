import { LightningElement, api } from 'lwc';
import { NavigationMixin } from 'lightning/navigation';
import getCarPicture from '@salesforce/apex/UserRender.fetchCarModel';

export default class DisplayCar extends NavigationMixin(LightningElement) {

    @api car;
    error;
    @api recordId;
    count = 0;
    recordImage;
    maxCount;

    connectedCallback(){
        getCarPicture().then(result=>{
            this.maxCount = result.length-1;
            this.car = result[this.count];
            this.recordId = this.car.Id;
            this.recordImage = this.car.Image__c;
            console.log(this.recordId);
            this.template.querySelector('c-display-car-model-details').childMethod(this.recordId);
        }).catch(err =>{
            this.error = err;
        })
    }
    
    navigateToBuyCar() {
        const modal = this.template.querySelector("c-display-car-modal");
        modal.carModel = this.recordId;
        modal.show();
    }

    handleNext(){
        if(this.count<this.maxCount){
            this.count++;
        }
        getCarPicture().then(result=>{            
            this.car = result[this.count];
            this.recordId = this.car.Id;
            this.recordImage = this.car.Image__c;
            this.template.querySelector('c-display-car-model-details').childMethod(this.recordId);
        }).catch(err =>{
            this.error = err;
        })
    }

    handlePrevious(){
        if(this.count>0){
            this.count--;
        }
        getCarPicture().then(result=>{
            
            this.car = result[this.count];
            this.recordId = this.car.Id;
            this.recordImage = this.car.Image__c;
            this.template.querySelector('c-display-car-model-details').childMethod(this.recordId);
            console.log(this.count);
        }).catch(err =>{
            this.error = err;
        })
    }
}
