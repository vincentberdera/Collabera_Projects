import { LightningElement, api } from 'lwc';
import { NavigationMixin } from 'lightning/navigation';
import getCarBooking from '@salesforce/apex/UserRender.fetchCarBooking';

const col3 = [
    {
        label: 'Reference ID',
        fieldName: 'NameUrl3',
        type:'url',
        typeAttributes:{
            label:{
                fieldName:'Name3'
            }
        }
    },
   {
        label: 'Car Model',
        fieldName: 'CarModelUrl3',
        type:'url',
        typeAttributes:{
            label:{
                fieldName:'CarModelName3'
            }
        }
    },
    {
        label: 'Account',
        fieldName: 'AccountUrl3',
        type:'url',
        typeAttributes:{
            label:{
                fieldName:'AccountName3'
            }
        }
    },
    {
        label: 'Manufacturer',
        fieldName: 'Manufacturer3',
        type: 'text'
    },
    {
        label: 'Start Date',
        fieldName: 'StartDate',
        type: 'date'
    },
    {
        label: 'End Date',
        fieldName: 'EndDate',
        type: 'date'
    },
    {
        label: 'Price',
        fieldName: 'Price3',
        type: 'currency'
    },
    {
        label: 'Status',
        fieldName: 'Status3',
        type: 'text'
    },
    {
        label: 'Stage',
        fieldName: 'Stage3',
        type: 'text'
    },
    {type: "button",
        typeAttributes: {  
        label: 'Edit',  
        name: 'Edit',  
        title: 'Edit',  
        disabled: false,  
        value: 'Id',  
        iconPosition: 'left'  
    }}
]

export default class CarBookingRecords extends NavigationMixin(LightningElement) {


    showModal=false;

    columns3 = col3;
    result3;
    error3;

    @api show(){
        this.showModal = true;
    }

    handleDialogClose(){
        this.showModal = false;
    }

    handleKeys(e){
        this.searchKey = e.target.value;
    }

    connectedCallback(){
        this.handleCarBookingData();
    }
    
    navigateToNewCarBooking() {
        this[NavigationMixin.Navigate]({
            type: 'standard__objectPage',
            attributes: {
                objectApiName: 'Car_Booking__c',
                actionName: 'new'
            }
        })
    }


    handleCarBookingData(){
        getCarBooking({'Search':this.searchKey}).then( res =>{
            //function(res)
            if(res)
            {
                let finalChange=[];
                res.forEach(row =>{
                    let objectStruct = {};
                    objectStruct.Id = row.Id;
                    objectStruct.Name3 = row.Name;
                    objectStruct.CarModelName3 = row.Car_Model__r.Name;
                    objectStruct.AccountName3 = row.Account__r.Name;
                    objectStruct.Manufacturer3 = row.Car_Manufacturer__c;
                    objectStruct.StartDate = row.Start_Date__c;
                    objectStruct.EndDate = row.End_Date__c;
                    objectStruct.Price3 = row.Price__c;
                    objectStruct.Status3 = row.Status__c;
                    objectStruct.Stage3 = row.Stage__c;
                    objectStruct.NameUrl3 = 'https://carmanufacturer-dev-ed.lightning.force.com/lightning/r/Car_Booking__c/'+row.Id+'/view';
                    objectStruct.CarModelUrl3 = 'https://carmanufacturer-dev-ed.lightning.force.com/lightning/r/Car_Model__c/'+row.Car_Model__r.Id+'/view';
                    objectStruct.AccountUrl3 = 'https://carmanufacturer-dev-ed.lightning.force.com/lightning/r/Account/'+row.Account__r.Id+'/view';
                    finalChange.push(objectStruct);
                })
                this.result3 = finalChange;

            }
        }).catch(err =>{
            this.error3 = err;
        })
    }

    handleShowModal(event){
        const modal = this.template.querySelector("c-car-booking-modal");
        modal.idPassed = event.detail.row.Id;
        modal.show();
    }

}