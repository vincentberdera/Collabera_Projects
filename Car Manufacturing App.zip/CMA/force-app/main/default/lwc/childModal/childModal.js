import { LightningElement, api} from 'lwc';

import checkUser from '@salesforce/apex/UserRender.checkUser';
import CAR_MODEL_ID from '@salesforce/schema/Car_Model__c.Id';
import CAR_MODEL_NAME from '@salesforce/schema/Car_Model__c.Name';
import SEATING_CAPACITY from '@salesforce/schema/Car_Model__c.Seating_Capacity__c';
import WIDTH from '@salesforce/schema/Car_Model__c.Width__c';
import LENGTH from '@salesforce/schema/Car_Model__c.Length__c';
import HEIGHT from '@salesforce/schema/Car_Model__c.Height__c';
import ENGINE_TYPE from '@salesforce/schema/Car_Model__c.Engine_Type__c';
import ENGINE_DISPLACEMENT from '@salesforce/schema/Car_Model__c.Engine_Displacement__c';
import FUEL_TYPE from '@salesforce/schema/Car_Model__c.Fuel_Type__c';
import FUEL_CAPACITY from '@salesforce/schema/Car_Model__c.Fuel_Capacity__c';
import PRICE from '@salesforce/schema/Car_Model__c.Price__c';
import STAGE from '@salesforce/schema/Car_Model__c.Stage__c';
import QNS_DOCUMENT_LINK from '@salesforce/schema/Car_Model__c.Quality_And_Safety_Check_Documents__c';

import { updateRecord } from 'lightning/uiRecordApi';
import {ShowToastEvent} from 'lightning/platformShowToastEvent';

const CSS_CLASS = "modal-hidden";

export default class ChildModal extends LightningElement {
    showModal=false;
    objectName = 'Car_Model__c';
    userProfile;

    carModelName = CAR_MODEL_NAME;
    seatingCapacity = SEATING_CAPACITY;
    width = WIDTH;
    length = LENGTH;
    height = HEIGHT;
    engineType = ENGINE_TYPE;
    engineDisplacement = ENGINE_DISPLACEMENT;
    fuelType = FUEL_TYPE;
    fuelCapacity = FUEL_CAPACITY;
    price = PRICE;
    stage = STAGE;
    qualityAndSafetyCheckDocumentsLink = QNS_DOCUMENT_LINK;

    @api idPassed;

    @api show(){
        this.showModal = true;
    }

    connectedCallback(){
        checkUser().then(result => {
            this.userProfile = result;
        })
        .catch(error => {
            this.userProfile = error;
        })
    }

    handleDialogClose(){
        this.showModal = false;
    }

    handleCancelEditForm()
    {
        this.showModal = false;
    }

    handleSaveEditForm()
    {
        const recordField = {};
        
        recordField[CAR_MODEL_ID.fieldApiName] = this.idPassed;
        recordField[CAR_MODEL_NAME.fieldApiName] = this.template.querySelector("[data-field='Name']").value;
        recordField[SEATING_CAPACITY.fieldApiName] = this.template.querySelector("[data-field='Seating_Capacity__c']").value;
        recordField[WIDTH.fieldApiName] = this.template.querySelector("[data-field='Width__c']").value;
        recordField[LENGTH.fieldApiName] = this.template.querySelector("[data-field='Length__c']").value;
        recordField[HEIGHT.fieldApiName] = this.template.querySelector("[data-field='Height__c']").value;
        recordField[ENGINE_TYPE.fieldApiName] = this.template.querySelector("[data-field='Engine_Type__c']").value;
        recordField[ENGINE_DISPLACEMENT.fieldApiName] = this.template.querySelector("[data-field='Engine_Displacement__c']").value;
        recordField[FUEL_TYPE.fieldApiName] = this.template.querySelector("[data-field='Fuel_Type__c']").value;
        recordField[FUEL_CAPACITY.fieldApiName] = this.template.querySelector("[data-field='Fuel_Capacity__c']").value;
        recordField[PRICE.fieldApiName] = this.template.querySelector("[data-field='Price__c']").value;
        recordField[STAGE.fieldApiName] = this.template.querySelector("[data-field='Stage__c']").value;
        recordField[QNS_DOCUMENT_LINK.fieldApiName] = this.template.querySelector("[data-field='Quality_And_Safety_Check_Documents__c']").value;

        if(this.userProfile === 'System Administrator' || this.userProfile === "Company Executives"){
            const recordInput ={
                fields:recordField
            }
            updateRecord(recordInput).then(() => {
                this.dispatchEvent(
                    new ShowToastEvent({
                        title: 'Success',
                        message: 'Car model updated',
                        variant: 'success'
                    })
                );
                window.location.reload();
            })
            .catch(error => {
                this.dispatchEvent(
                    new ShowToastEvent({
                        title: 'Error updating record',
                        message: error.body.message,
                        variant: 'error'
                    })
                );
            });
            this.showModal = false;
        }   
        else if(this.userProfile === "Factory Executives"){
            if(recordField[STAGE.fieldApiName] == "Manufacturing" || recordField[STAGE.fieldApiName] == "Manufactured"){
                console.log(this.userProfile);
                const recordInput ={
                    fields:recordField
                }
                updateRecord(recordInput).then(() => {
                    this.dispatchEvent(
                        new ShowToastEvent({
                            title: 'Success',
                            message: 'Car model updated',
                            variant: 'success'
                        })
                    );
                    window.location.reload();
                })
                .catch(error => {
                    this.dispatchEvent(
                        new ShowToastEvent({
                            title: 'Error updating record',
                            message: error.body.message,
                            variant: 'error'
                        })
                    );
                });
                this.showModal = false;
            }
            else{
                this.dispatchEvent(
                    new ShowToastEvent({
                        title: 'Error updating record',
                        message: 'Factory Executives is not allowed to update records if it is not in Manufacturing Stage or Manufactured Stage',
                        variant: 'error'
                    })
                );
                this.showModal = false;
            }
        }   
        else if(this.userProfile === "Quality Analysts"){
            if(recordField[STAGE.fieldApiName] == "Manufactured"){
                console.log(this.userProfile);
                const recordInput ={
                    fields:recordField
                }
                updateRecord(recordInput).then(() => {
                    this.dispatchEvent(
                        new ShowToastEvent({
                            title: 'Success',
                            message: 'Car model updated',
                            variant: 'success'
                        })
                    );
                    window.location.reload();
                })
                .catch(error => {
                    this.dispatchEvent(
                        new ShowToastEvent({
                            title: 'Error updating record',
                            message: error.body.message,
                            variant: 'error'
                        })
                    );
                });
                this.showModal = false;
            }
            else if(recordField[STAGE.fieldApiName] == "Ready for Launch" && (recordField[QNS_DOCUMENT_LINK.fieldApiName] != "" || recordField[QNS_DOCUMENT_LINK.fieldApiName] != null)){
                console.log(this.userProfile);
                const recordInput ={
                    fields:recordField
                }
                updateRecord(recordInput).then(() => {
                    this.dispatchEvent(
                        new ShowToastEvent({
                            title: 'Success',
                            message: 'Car model updated',
                            variant: 'success'
                        })
                    );
                    window.location.reload();
                })
                .catch(error => {
                    this.dispatchEvent(
                        new ShowToastEvent({
                            title: 'Error updating record',
                            message: error.body.message,
                            variant: 'error'
                        })
                    );
                });
                this.showModal = false;
            }
            else{
                this.dispatchEvent(
                    new ShowToastEvent({
                        title: 'Error updating record',
                        message: 'Quality Analysts are not allowed to update records if it is not in Manufactured Stage or Ready for Launch Stage',
                        variant: 'error'
                    })
                );
                this.showModal = false;
            }
        }
        else if(this.userProfile === "Sales Executives"){
            if(recordField[STAGE.fieldApiName] == "Ready for Launch" || recordField[STAGE.fieldApiName] == "Launched"){
                console.log(this.userProfile);
                const recordInput ={
                    fields:recordField
                }
                updateRecord(recordInput).then(() => {
                    this.dispatchEvent(
                        new ShowToastEvent({
                            title: 'Success',
                            message: 'Car model updated',
                            variant: 'success'
                        })
                    );
                    window.location.reload();
                })
                .catch(error => {
                    this.dispatchEvent(
                        new ShowToastEvent({
                            title: 'Error updating record',
                            message: error.body.message,
                            variant: 'error'
                        })
                    );
                });
                this.showModal = false;
            }
            else{
                this.dispatchEvent(
                    new ShowToastEvent({
                        title: 'Error updating record',
                        message: 'Sales Executives are not allowed to update records if it is not in Ready for Launch Stage or Launched Stage',
                        variant: 'error'
                    })
                );
                this.showModal = false;
            }
        }
        else{
            this.dispatchEvent(
                new ShowToastEvent({
                    title: 'Error updating record',
                    message: 'You don not have an access to edit Car Model Details',
                    variant: 'error'
                })
            );
            this.showModal = false;
        }

        
    }
}