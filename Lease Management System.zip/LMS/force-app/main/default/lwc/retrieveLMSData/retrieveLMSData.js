import { LightningElement } from 'lwc';
import getContract from '@salesforce/apex/LMSDataController.fetchContract';
import getBuilding from '@salesforce/apex/LMSDataController.fetchBuilding';
import getContact from '@salesforce/apex/LMSDataController.fetchContact';
import getUnit from '@salesforce/apex/LMSDataController.fetchUnit';
const col = [
    {
        label:'Contract Number',
        fieldName: 'ContractUrl',
        type:'url',
        typeAttributes:{
            label: {
                fieldName: 'ContractNumber'
            }            
        }
    },
    {
        label:'Building Name',
        fieldName: 'BuildingName',
        type:'text'
    },
    {
        label:'Flat Number',
        fieldName: 'FlatNumber',
        type:'number'
    },
    {
        label:'Tenant Name',
        fieldName: 'TenantUrl',
        type:'url',
        typeAttributes:{
            label: {
                fieldName: 'TenantName'
            }            
        }
    },
    {
        label:'Start Date',
        fieldName: 'StartDate',
        type:'date'
    },
    {
        label:'End Date',
        fieldName: 'EndDate',
        type:'date'
    },
    {
        label:'Price',
        fieldName: 'Price',
        type:'currency'
    },
    {
        label:'Total Price',
        fieldName: 'TotalPrice',
        type:'currency'
    },
    {
        label:'Discount',
        fieldName: 'Discount',
        type:'percentage'
    },
    {
        label:'Status',
        fieldName: 'Status',
        type:'text'
    }
];

const col2 = [
    {
        label:'Building Name',
        fieldName: 'BuildingUrl',
        type:'url',
        typeAttributes:{
            label: {
                fieldName: 'BuildingName'
            }            
        }
    },
    {
        label:'Address',
        fieldName: 'Address',
        type:'text'
    },
    {
        label:'State',
        fieldName: 'State',
        type:'text'
    },
    {
        label:'District',
        fieldName: 'District',
        type:'text'
    },
    {
        label:'Storey',
        fieldName: 'Storey',
        type:'number'
    },
    {
        label:'Total Revenue',
        fieldName: 'TotalRevenue',
        type:'currency'
    }
];

const col3 = [
    {
        label:'Contact Name',
        fieldName: 'ContactUrl3',
        type:'url',
        typeAttributes:{
            label: {
                fieldName: 'ContactName3'
            }            
        }
    },
    {
        label:'Account Name',
        fieldName: 'AccountUrl3',
        type:'url',
        typeAttributes:{
            label: {
                fieldName: 'AccountName3'
            }            
        }
    },
    {
        label:'Account Site',
        fieldName: 'AccountSite',
        type:'text'
    },
    {
        label:'Phone',
        fieldName: 'Phone3',
        type:'phone'
    },
    {
        label:'Email',
        fieldName: 'Email3',
        type:'email'
    }
];

const col4 = [
    {
        label:'Unit Number',
        fieldName: 'UnitUrl4',
        type:'url',
        typeAttributes:{
            label: {
                fieldName: 'UnitNumber'
            }            
        }
    },
    {
        label:'Building Name',
        fieldName: 'BuildingUrl4',
        type:'url',
        typeAttributes:{
            label: {
                fieldName: 'BuildingName4'
            }            
        }
    },
    {
        label:'Floor',
        fieldName: 'Floor4',
        type:'number'
    },
    {
        label:'Flat No',
        fieldName: 'FlatNo4',
        type:'number'
    },
    {
        label:'Contact Name',
        fieldName: 'ContactUrl4',
        type:'url',
        typeAttributes:{
            label: {
                fieldName: 'ContactName4'
            }            
        }
    },
    {
        label:'Contract #',
        fieldName: 'ContractUrl4',
        type:'url',
        typeAttributes:{
            label: {
                fieldName: 'ContractNumber4'
            }            
        }
    },
    {
        label:'Flat Type',
        fieldName: 'FlatType4',
        type:'text'
    },
    {
        label:'Price',
        fieldName: 'Price4',
        type:'currency'
    }
];

export default class RetrieveLMSData extends LightningElement {
    
    searchKey;

    columns = col;
    result;
    error;

    columns2 = col2;
    result2;
    error2;

    columns3 = col3;
    result3;
    error3;

    columns4 = col4;
    result4;
    error4;

    handleKeys(e){
        this.searchKey = e.target.value;
        this.handleContractData();
    }

    handleContractData(){
        getContract({'Search':this.searchKey}).then( res=>{
            //function(res)

            if(this.searchKey !== ''){
                let finalChange=[];
                res.forEach(row=>{
                    let objectStruct = {};
                    objectStruct.Id = row.Id;
                    objectStruct.ContractNumber = row.Name;                    
                    objectStruct.BuildingName = row.Building_Name__c;
                    objectStruct.FlatNumber = row.Flat_No__c;
                    objectStruct.TenantName = row.Tenant__r.Name;
                    objectStruct.StartDate = row.Start_Date__c;
                    objectStruct.EndDate = row.End_Date__c;
                    objectStruct.Price = row.Price__c;
                    objectStruct.TotalPrice = row.Total_Price__c;
                    objectStruct.Discount = row.Discount__c;
                    objectStruct.Status = row.Status__c;
                    objectStruct.ContractUrl = 'https://trainingdevelopers-dev-ed.lightning.force.com/lightning/r/Contract__c/'+row.Id+'/view';
                    objectStruct.TenantUrl = 'https://trainingdevelopers-dev-ed.lightning.force.com/lightning/r/Contact/'+row.Tenant__r.Id+'/view';
                    finalChange.push(objectStruct);
                })
                this.result = finalChange;
            }
            else{
                let finalChange=[];
                let objectStruct = {};
                finalChange.push(objectStruct);
                this.result = finalChange;
            }
        }).catch(err => {
            this.error=err;
        })       
        this.handleBuildingData();
    }

    handleBuildingData(){
        getBuilding({'Search':this.searchKey}).then( res=>{
            //function(res)
            if(this.searchKey !== ''){
                let finalChange=[];
                res.forEach(row=>{
                    let objectStruct = {};
                    objectStruct.Id = row.Id;
                    objectStruct.BuildingName = row.Name;               
                    objectStruct.Address = row.Address__c;
                    objectStruct.State = row.State__c;
                    objectStruct.District = row.District__c;
                    objectStruct.Storey = row.Storey__c;
                    objectStruct.TotalRevenue = row.Total_Revenue__c;
                    objectStruct.BuildingUrl = 'https://trainingdevelopers-dev-ed.lightning.force.com/lightning/r/Building__c/'+row.Id+'/view';
                    finalChange.push(objectStruct);
                })
                this.result2 = finalChange;
            }
            else{
                let finalChange=[];
                let objectStruct = {};
                finalChange.push(objectStruct);
                this.result2 = finalChange;
            }
        }).catch(err => {
            this.error2=err;
        })      
        this.handleContactData(); 
    }

    handleContactData(){
        getContact({'Search':this.searchKey}).then( res=>{
            //function(res)
            if(this.searchKey !== ''){
                let finalChange=[];
                res.forEach(row=>{
                    let objectStruct = {};
                    objectStruct.Id = row.Id;
                    objectStruct.ContactName3 = row.Name;               
                    objectStruct.AccountName3 = row.Account.Name;
                    objectStruct.Site3 = row.Account.Site;
                    objectStruct.Phone3 = row.Phone;
                    objectStruct.Email3 = row.Email;
                    objectStruct.TotalRevenue = row.Total_Revenue__c;
                    objectStruct.ContactUrl3 = 'https://trainingdevelopers-dev-ed.lightning.force.com/lightning/r/Contact/'+row.Id+'/view';
                    objectStruct.AccountUrl3 = 'https://trainingdevelopers-dev-ed.lightning.force.com/lightning/r/Account/'+row.AccountId+'/view';
                    finalChange.push(objectStruct);
                })
                this.result3 = finalChange;
            }
            else{
                let finalChange=[];
                let objectStruct = {};
                finalChange.push(objectStruct);
                this.result3 = finalChange;
            }
        }).catch(err => {
            this.error3=err;
        })      
        this.handleUnitData(); 
    }

    handleUnitData(){
        getUnit({'Search':this.searchKey}).then( res=>{
            //function(res)
            if(this.searchKey !== ''){
                let finalChange=[];
                res.forEach(row=>{
                    let objectStruct = {};
                    objectStruct.Id = row.Id;
                    objectStruct.UnitNumber = row.Name;               
                    objectStruct.BuildingName4 = row.Building_Name__r.Name;
                    objectStruct.Floor4 = row.Floor__c;
                    objectStruct.FlatNo4 = row.Flat_No__c;
                    objectStruct.ContactName4 = row.Contact__r.Name;
                    objectStruct.ContractNumber4 = row.Contract__r.Name;
                    objectStruct.FlatType4 = row.Flat_Type__c;
                    objectStruct.Price4 = row.Price__c;
                    objectStruct.UnitUrl4 = 'https://trainingdevelopers-dev-ed.lightning.force.com/lightning/r/Unit__c/'+row.Id+'/view';
                    objectStruct.BuildingUrl4 = 'https://trainingdevelopers-dev-ed.lightning.force.com/lightning/r/Building__c/'+row.Building_Name__c+'/view';
                    objectStruct.ContactUrl4 = 'https://trainingdevelopers-dev-ed.lightning.force.com/lightning/r/Contact/'+row.Contact__c+'/view';
                    objectStruct.ContractUrl4 = 'https://trainingdevelopers-dev-ed.lightning.force.com/lightning/r/Contract__c/'+row.Contract__c+'/view';
                    finalChange.push(objectStruct);
                })
                this.result4 = finalChange;
            }
            else{
                let finalChange=[];
                let objectStruct = {};
                finalChange.push(objectStruct);
                this.result4 = finalChange;
            }
        }).catch(err => {
            this.error4=err;
        })       
    }
}