import { LightningElement, api, wire } from 'lwc';
import getContract from '@salesforce/apex/emailContract.sendContract'

export default class EmailContract extends LightningElement {
    @api recordId;
    result;
    error;
    display='hide tablemargin'
    handleCloseButtonClick(){
        this.display='hide tablemargin'
    }
    @wire(getContract,{contractId:'$recordId'})
    contractdata({error,data})
    {
        if(data){
            this.result=data;
            console.table(data);
        } else{
            if(error){
                console.log(error);
            }
        }
    }
}