import { LightningElement } from 'lwc';
import getCase from '@salesforce/apex/DataController.fetchCase';
import getAccount from '@salesforce/apex/DataController.fetchAccount';
import getContact from '@salesforce/apex/DataController.fetchContact';
const col = [
    {
        label:'Case Number',
        fieldName: 'CaseUrl',
        type:'url',
        typeAttributes:{
            label: {
                fieldName: 'CaseNumber'
            }            
        }
    },
    {
        label:'Subject',
        fieldName: 'CaseUrl',
        type:'url',
        typeAttributes:{
            label: {
                fieldName: 'Subject'
            }            
        }
    },
    {
        label:'Account Name',
        fieldName: 'AccountUrl',
        type:'url',
        typeAttributes:{
            label: {
                fieldName: 'AccountName'
            }            
        }
    },
    {
        label:'Contact Name',
        fieldName: 'ContactUrl',
        type:'url',
        typeAttributes:{
            label: {
                fieldName: 'ContactName'
            }            
        }
    }
];


const col2 = [
    {
        label:'Account Name',
        fieldName: 'AccountUrl2',
        type:'url',
        typeAttributes:{
            label: {
                fieldName: 'AccountName2'
            }            
        }
    },
    {
        label:'Phone',
        fieldName: 'Phone2',
        type:'phone'
    },
    {
        label:'Industry',
        fieldName: 'Industry',
        type:'text'
    },
    {
        label:'Type',
        fieldName: 'Type',
        type:'text'
    }
];


const col3 = [
    {
        label:'Contact Name',
        fieldName: 'ContactUrl3',
        type:'url',
        typeAttributes:{
            label: {
                fieldName: 'ContactName3'
            }            
        }
    },
    {
        label:'Phone',
        fieldName: 'Phone3',
        type:'phone'
    },
    {
        label:'Email',
        fieldName: 'Email',
        type:'email'
    },
    {
        label:'Account Name',
        fieldName: 'AccountUrl3',
        type:'url',
        typeAttributes:{
            label: {
                fieldName: 'AccountName3'
            }            
        }
    }
];

export default class RetrieveData extends LightningElement {

    columns = col;
    result;
    error;
    searchKey;
    
    columns2 = col2;
    result2;
    error2;
    
    columns3 = col3;
    result3;
    error3;

    handleKeys(e){
        this.searchKey = e.target.value;
        this.handleCaseData();
    }

    handleCaseData(){
        getCase({'Search':this.searchKey}).then( res=>{
            //function(res)

            if(this.searchKey !== ''){
                let finalChange=[];
                res.forEach(row=>{
                    let objectStruct = {};
                    objectStruct.Id = row.Id;
                    objectStruct.CaseNumber = row.CaseNumber;
                    objectStruct.Subject = row.Subject;
                    objectStruct.AccountName = row.Account.Name;
                    objectStruct.ContactName = row.Contact.Name;
                    objectStruct.CaseUrl = 'https://trainingdevelopers-dev-ed.lightning.force.com/lightning/r/Case/'+row.Id+'/view';
                    objectStruct.AccountUrl = 'https://trainingdevelopers-dev-ed.lightning.force.com/lightning/r/Account/'+row.Account.Id+'/view';
                    objectStruct.ContactUrl = 'https://trainingdevelopers-dev-ed.lightning.force.com/lightning/r/Contact/'+row.Contact.Id+'/view';
                    finalChange.push(objectStruct);
                })
                this.result = finalChange;
            }
            else{
                let finalChange=[];
                let objectStruct = {};
                finalChange.push(objectStruct);
                this.result = finalChange;
            }
        }).catch(err => {
            this.error=err;
        })
        this.handleAccountData();        
    }

    handleAccountData(){
        getAccount({'Search':this.searchKey}).then( res=>{
            //function(res)

            if(this.searchKey !== ''){
                let finalChange=[];
                res.forEach(row=>{
                    let objectStruct = {};
                    objectStruct.Id = row.Id;
                    objectStruct.Subject = row.Subject;
                    objectStruct.AccountName2 = row.Account.Name;
                    objectStruct.Phone2 = row.Account.Phone;
                    objectStruct.Industry = row.Account.Industry;
                    objectStruct.Type = row.Account.Type;
                    objectStruct.AccountUrl2 = 'https://trainingdevelopers-dev-ed.lightning.force.com/lightning/r/Account/'+row.Account.Id+'/view';
                    finalChange.push(objectStruct);
                })
                this.result2 = finalChange;
            }
            else{
                let finalChange=[];
                let objectStruct = {};
                finalChange.push(objectStruct);
                this.result2 = finalChange;
            }
        }).catch(err => {
            this.error2=err;
        })
        this.handleContactData();
    }

    handleContactData(){
        getContact({'Search':this.searchKey}).then( res=>{
            //function(res)

           if(this.searchKey !== ''){
                let finalChange=[];
                res.forEach(row=>{
                    let objectStruct = {};
                    objectStruct.Id = row.Id;
                    objectStruct.Subject = row.Subject;
                    objectStruct.ContactName3 = row.Contact.Name;
                    objectStruct.Phone3 = row.Contact.Phone;
                    objectStruct.Email = row.Contact.Email;
                    objectStruct.AccountName3 = row.Contact.Account.Name;
                    objectStruct.ContactUrl3 = 'https://trainingdevelopers-dev-ed.lightning.force.com/lightning/r/Contact/'+row.Contact.Id+'/view';
                    objectStruct.AccountUrl3 = 'https://trainingdevelopers-dev-ed.lightning.force.com/lightning/r/Account/'+row.Contact.Account.Id+'/view';
                    finalChange.push(objectStruct);
                })
                this.result3 = finalChange;
            }
            else{
                let finalChange=[];
                let objectStruct = {};
                finalChange.push(objectStruct);
                this.result3 = finalChange;
            }
        }).catch(err => {
            this.error3=err;
        })
    }

}